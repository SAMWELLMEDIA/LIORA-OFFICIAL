const APPROVED_PUBLIC_PATHS = new Set([
  "/",
  "/app",
  "/about",
  "/contact",
  "/faq",
  "/forgot-password",
  "/how-it-works",
  "/login",
  "/privacy",
  "/privacy-policy",
  "/packages",
  "/refund-policy",
  "/register",
  "/reset-password",
  "/is-liora-legit-or-scam",
  "/terms",
  "/terms-and-conditions",
  "/testimonials",
  "/top-earners",
  "/withdrawals",
]);

export function isApprovedPublicPath(href: string): boolean {
  if (!href.startsWith("/") || href.startsWith("//") || href.includes("\\")) return false;

  try {
    const url = new URL(href, "https://liora.invalid");
    if (url.origin !== "https://liora.invalid") return false;
    const pathname = url.pathname === "/" ? "/" : url.pathname.replace(/\/+$/, "");
    return APPROVED_PUBLIC_PATHS.has(pathname);
  } catch {
    return false;
  }
}
