import { check, index, pgTable, text, timestamp, varchar } from "drizzle-orm/pg-core";
import { sql } from "drizzle-orm";

export const lioraWebsiteAnalyticsEventsTable = pgTable(
  "liora_website_analytics_events",
  {
    id: text("id").primaryKey(),
    visitorHash: text("visitor_hash").notNull(),
    eventType: varchar("event_type", { length: 32 }).notNull(),
    path: varchar("path", { length: 200 }).notNull(),
    deviceType: varchar("device_type", { length: 16 }).notNull().default("unknown"),
    occurredAt: timestamp("occurred_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [
    check(
      "liora_website_analytics_event_type_check",
      sql`${table.eventType} IN ('page_view', 'register_click', 'registration_begin')`,
    ),
    check(
      "liora_website_analytics_device_type_check",
      sql`${table.deviceType} IN ('mobile', 'desktop', 'tablet', 'other', 'unknown')`,
    ),
    check(
      "liora_website_analytics_path_check",
      sql`${table.path} LIKE '/%' AND ${table.path} NOT LIKE '/api/%' AND ${table.path} NOT LIKE '/admin/%' AND length(${table.path}) <= 200`,
    ),
    index("liora_website_analytics_event_time_idx").on(table.eventType, table.occurredAt),
    index("liora_website_analytics_path_time_idx").on(table.path, table.occurredAt),
    index("liora_website_analytics_visitor_time_idx").on(table.visitorHash, table.occurredAt),
    index("liora_website_analytics_device_time_idx").on(table.deviceType, table.occurredAt),
  ],
);

export type LioraWebsiteAnalyticsEvent = typeof lioraWebsiteAnalyticsEventsTable.$inferSelect;
