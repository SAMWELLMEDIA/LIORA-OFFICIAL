import { check, index, jsonb, pgTable, text, timestamp, varchar } from "drizzle-orm/pg-core";
import { sql } from "drizzle-orm";
import { lioraAdminUsersTable } from "./liora-admin";

export type LioraAdminSecurityEventType =
  | "admin.login.success"
  | "admin.login.failure"
  | "admin.login.rate_limited"
  | "admin.logout.success"
  | "admin.api.unauthorized";

export const lioraAdminSecurityEventsTable = pgTable(
  "liora_admin_security_events",
  {
    id: text("id").primaryKey(),
    adminId: text("admin_id").references(() => lioraAdminUsersTable.id, { onDelete: "set null" }),
    eventType: varchar("event_type", { length: 48 }).$type<LioraAdminSecurityEventType>().notNull(),
    outcome: varchar("outcome", { length: 16 }).notNull(),
    httpMethod: varchar("http_method", { length: 12 }),
    route: varchar("route", { length: 180 }),
    sourceFingerprint: varchar("source_fingerprint", { length: 64 }),
    details: jsonb("details").$type<Record<string, string | number | boolean | null>>().notNull().default({}),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [
    check("liora_admin_security_event_type_check", sql`${table.eventType} IN ('admin.login.success', 'admin.login.failure', 'admin.login.rate_limited', 'admin.logout.success', 'admin.api.unauthorized')`),
    check("liora_admin_security_outcome_check", sql`${table.outcome} IN ('success', 'failure', 'blocked')`),
    index("liora_admin_security_created_idx").on(table.createdAt),
    index("liora_admin_security_admin_created_idx").on(table.adminId, table.createdAt),
    index("liora_admin_security_source_created_idx").on(table.sourceFingerprint, table.createdAt),
  ],
);

export type LioraAdminSecurityEvent = typeof lioraAdminSecurityEventsTable.$inferSelect;
