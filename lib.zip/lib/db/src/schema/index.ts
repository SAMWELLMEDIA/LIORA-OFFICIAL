export * from "./contact-submissions";
export * from "./testimonials";
export * from "./liora-accounts";
export * from "./liora-admin";
export * from "./liora-admin-member-activity";
export * from "./liora-admin-security-events";
export * from "./liora-visitor-analytics";
export * from "./liora-website-analytics";
export * from "./liora-payments";
export * from "./liora-email-marketing";
export * from "./liora-push-notifications";
export * from "./liora-homepage-content";
export * from "./liora-website-content";
export * from "./liora-platform-settings";
export * from "./liora-seo-settings";

// Export your models here. Add one export per file
// export * from "./posts";
//
// Each model/table should ideally be split into different files.
// Each model/table should define a Drizzle table, insert schema, and types:
//
//   import { pgTable, text, serial } from "drizzle-orm/pg-core";
//   import { createInsertSchema } from "drizzle-zod";
//   import { z } from "zod/v4";
//
//   export const postsTable = pgTable("posts", {
//     id: serial("id").primaryKey(),
//     title: text("title").notNull(),
//   });
//
//   export const insertPostSchema = createInsertSchema(postsTable).omit({ id: true });
//   export type InsertPost = z.infer<typeof insertPostSchema>;
//   export type Post = typeof postsTable.$inferSelect;

export {}