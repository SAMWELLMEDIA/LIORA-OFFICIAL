import { sql } from "drizzle-orm";
import {
  check,
  index,
  jsonb,
  pgTable,
  text,
  timestamp,
  varchar,
} from "drizzle-orm/pg-core";
import { lioraAdminUsersTable } from "./liora-admin";

export type LioraPlatformSettings = {
  general: {
    displayName: string;
    description: string;
    slogan: string;
  };
  branding: {
    logoPath: string;
    faviconPath: string;
    approvedAssets: string[];
  };
  maintenance: {
    enabled: boolean;
    message: string;
    expectedReturn: string;
  };
  support: {
    visible: boolean;
  };
  regional: {
    timezone: string;
    currency: string;
    dateFormat: "DD/MM/YYYY" | "MM/DD/YYYY" | "YYYY-MM-DD";
    numberLocale: "en-NG" | "en-GH" | "en-ZA" | "en-US";
  };
  preferences: {
    announcementVisible: boolean;
  };
};

export type LioraAnnouncementStyle = "notice" | "update" | "important";
export type LioraAnnouncementStatus = "draft" | "published" | "unpublished";
export type LioraAnnouncement = {
  id: string;
  title: string;
  message: string;
  style: LioraAnnouncementStyle;
  startsAt: string | null;
  endsAt: string | null;
  status: LioraAnnouncementStatus;
  createdAt: string;
  updatedAt: string;
  publishedAt: string | null;
};

export const lioraPlatformSettingsTable = pgTable(
  "liora_platform_settings",
  {
    id: varchar("id", { length: 24 }).primaryKey(),
    settings: jsonb("settings").$type<LioraPlatformSettings>().notNull(),
    updatedByAdminId: text("updated_by_admin_id").references(
      () => lioraAdminUsersTable.id,
      { onDelete: "set null" },
    ),
    updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [
    check("liora_platform_settings_singleton_check", sql`${table.id} = 'default'`),
  ],
);

export const lioraAnnouncementsTable = pgTable(
  "liora_platform_announcements",
  {
    id: text("id").primaryKey(),
    title: varchar("title", { length: 120 }).notNull(),
    message: text("message").notNull(),
    style: varchar("style", { length: 16 }).$type<LioraAnnouncementStyle>().notNull(),
    startsAt: timestamp("starts_at", { withTimezone: true }),
    endsAt: timestamp("ends_at", { withTimezone: true }),
    status: varchar("status", { length: 16 }).$type<LioraAnnouncementStatus>().notNull().default("draft"),
    createdByAdminId: text("created_by_admin_id").references(
      () => lioraAdminUsersTable.id,
      { onDelete: "set null" },
    ),
    updatedByAdminId: text("updated_by_admin_id").references(
      () => lioraAdminUsersTable.id,
      { onDelete: "set null" },
    ),
    publishedByAdminId: text("published_by_admin_id").references(
      () => lioraAdminUsersTable.id,
      { onDelete: "set null" },
    ),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
    updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
    publishedAt: timestamp("published_at", { withTimezone: true }),
  },
  (table) => [
    check("liora_platform_announcement_status_check", sql`${table.status} in ('draft', 'published', 'unpublished')`),
    check("liora_platform_announcement_style_check", sql`${table.style} in ('notice', 'update', 'important')`),
    check("liora_platform_announcement_window_check", sql`${table.endsAt} is null or ${table.startsAt} is null or ${table.endsAt} > ${table.startsAt}`),
    index("liora_platform_announcement_active_idx").on(table.status, table.startsAt, table.endsAt),
    index("liora_platform_announcement_updated_idx").on(table.updatedAt),
  ],
);

export const lioraPlatformSettingsAuditTable = pgTable(
  "liora_platform_settings_audit",
  {
    id: text("id").primaryKey(),
    adminId: text("admin_id").references(() => lioraAdminUsersTable.id, { onDelete: "set null" }),
    settingKey: varchar("setting_key", { length: 64 }).notNull(),
    previousValue: jsonb("previous_value"),
    newValue: jsonb("new_value"),
    reason: varchar("reason", { length: 500 }).notNull(),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [
    index("liora_platform_settings_audit_admin_created_idx").on(table.adminId, table.createdAt),
    index("liora_platform_settings_audit_key_created_idx").on(table.settingKey, table.createdAt),
    index("liora_platform_settings_audit_created_idx").on(table.createdAt),
  ],
);

export type LioraPlatformSettingsAudit = typeof lioraPlatformSettingsAuditTable.$inferSelect;
