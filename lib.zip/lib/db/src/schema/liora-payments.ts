import {
  boolean,
  check,
  date,
  index,
  integer,
  jsonb,
  numeric,
  pgTable,
  text,
  timestamp,
  uniqueIndex,
  varchar,
} from "drizzle-orm/pg-core";
import { sql } from "drizzle-orm";
import { lioraAccountsTable, lioraPaymentAttemptsTable } from "./liora-accounts";
import { lioraAdminUsersTable } from "./liora-admin";

export const lioraCountrySettingsTable = pgTable(
  "liora_country_settings",
  {
    country: varchar("country", { length: 80 }).primaryKey(),
    isoCode: varchar("iso_code", { length: 2 }).notNull().unique(),
    currency: varchar("currency", { length: 3 }).notNull(),
    visible: boolean("visible").notNull().default(true),
    registrationEnabled: boolean("registration_enabled").notNull().default(false),
    paymentEnabled: boolean("payment_enabled").notNull().default(false),
    paymentMethod: varchar("payment_method", { length: 24 }).notNull(),
    originalFee: numeric("original_fee", { precision: 14, scale: 2 }),
    discountedFee: numeric("discounted_fee", { precision: 14, scale: 2 }),
    discountEnabled: boolean("discount_enabled").notNull().default(false),
    promotionStartDate: date("promotion_start_date", { mode: "string" }),
    promotionEndDate: date("promotion_end_date", { mode: "string" }),
    welcomeBonus: numeric("welcome_bonus", { precision: 14, scale: 2 }),
    updatedByAdminId: text("updated_by_admin_id").references(
      () => lioraAdminUsersTable.id,
      { onDelete: "set null" },
    ),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
    updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [
    check("liora_country_settings_currency_check", sql`${table.currency} ~ '^[A-Z]{3}$'`),
    check("liora_country_settings_iso_check", sql`${table.isoCode} ~ '^[A-Z]{2}$'`),
    check("liora_country_settings_method_check", sql`${table.paymentMethod} IN ('flutterwave', 'bank_transfer')`),
    check("liora_country_settings_fees_positive", sql`(${table.originalFee} IS NULL OR ${table.originalFee} >= 0) AND (${table.discountedFee} IS NULL OR ${table.discountedFee} >= 0) AND (${table.welcomeBonus} IS NULL OR ${table.welcomeBonus} >= 0)`),
    check("liora_country_settings_discount_not_over_original", sql`${table.discountedFee} IS NULL OR ${table.originalFee} IS NULL OR ${table.discountedFee} <= ${table.originalFee}`),
    check("liora_country_settings_promotion_dates", sql`${table.promotionStartDate} IS NULL OR ${table.promotionEndDate} IS NULL OR ${table.promotionStartDate} <= ${table.promotionEndDate}`),
    index("liora_country_settings_visible_idx").on(table.visible),
    index("liora_country_settings_enabled_idx").on(table.registrationEnabled),
  ],
);

export const lioraRegistrationInterestsTable = pgTable(
  "liora_registration_interests",
  {
    id: text("id").primaryKey(),
    country: varchar("country", { length: 80 })
      .notNull()
      .references(() => lioraCountrySettingsTable.country, { onDelete: "restrict" }),
    fullName: varchar("full_name", { length: 120 }).notNull(),
    email: varchar("email", { length: 254 }).notNull(),
    privacyAcceptedAt: timestamp("privacy_accepted_at", { withTimezone: true }).notNull(),
    marketingEmailConsent: boolean("marketing_email_consent").notNull().default(false),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [
    uniqueIndex("liora_registration_interests_country_email_idx")
      .on(table.country, sql`lower(${table.email})`),
    index("liora_registration_interests_created_idx").on(table.createdAt),
  ],
);

export const lioraCountryBankAccountsTable = pgTable(
  "liora_country_bank_accounts",
  {
    id: text("id").primaryKey(),
    country: varchar("country", { length: 80 })
      .notNull()
      .references(() => lioraCountrySettingsTable.country, { onDelete: "restrict" }),
    bankName: varchar("bank_name", { length: 120 }).notNull(),
    accountName: varchar("account_name", { length: 120 }).notNull(),
    accountNumber: varchar("account_number", { length: 64 }).notNull(),
    branch: varchar("branch", { length: 120 }),
    swiftBic: varchar("swift_bic", { length: 20 }),
    iban: varchar("iban", { length: 34 }),
    instructions: text("instructions").notNull().default(""),
    active: boolean("active").notNull().default(false),
    isPrimary: boolean("is_primary").notNull().default(false),
    legacyConfigCountry: varchar("legacy_config_country", { length: 80 }).unique(),
    updatedByAdminId: text("updated_by_admin_id").references(
      () => lioraAdminUsersTable.id,
      { onDelete: "set null" },
    ),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
    updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [
    index("liora_country_bank_accounts_country_idx").on(table.country, table.active),
    uniqueIndex("liora_country_bank_accounts_active_primary_idx")
      .on(table.country)
      .where(sql`${table.active} = true AND ${table.isPrimary} = true`),
  ],
);

export const lioraCountryConfigurationAuditTable = pgTable(
  "liora_country_configuration_audit",
  {
    id: text("id").primaryKey(),
    adminId: text("admin_id").references(() => lioraAdminUsersTable.id, { onDelete: "set null" }),
    country: varchar("country", { length: 80 }).notNull(),
    configurationType: varchar("configuration_type", { length: 32 }).notNull(),
    action: varchar("action", { length: 40 }).notNull(),
    previousValue: jsonb("previous_value"),
    newValue: jsonb("new_value"),
    reason: text("reason").notNull(),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [
    index("liora_country_configuration_audit_country_created_idx").on(table.country, table.createdAt),
    index("liora_country_configuration_audit_admin_created_idx").on(table.adminId, table.createdAt),
    index("liora_country_configuration_audit_created_idx").on(table.createdAt),
  ],
);

export const lioraManualTransferConfigsTable = pgTable(
  "liora_manual_transfer_configs",
  {
    country: varchar("country", { length: 80 }).primaryKey(),
    currency: varchar("currency", { length: 3 }).notNull(),
    bankName: varchar("bank_name", { length: 120 }).notNull(),
    accountName: varchar("account_name", { length: 120 }).notNull(),
    accountNumber: varchar("account_number", { length: 64 }).notNull(),
    instructions: text("instructions").notNull().default(""),
    active: boolean("active").notNull().default(false),
    updatedAt: timestamp("updated_at", { withTimezone: true })
      .notNull()
      .defaultNow(),
  },
  (table) => [
    index("liora_manual_transfer_configs_active_idx").on(table.active),
    check("liora_manual_transfer_configs_currency_len", sql`char_length(${table.currency}) = 3`),
  ],
);

export const lioraReceiptUploadSlotsTable = pgTable(
  "liora_receipt_upload_slots",
  {
    id: text("id").primaryKey(),
    accountId: text("account_id")
      .notNull()
      .references(() => lioraAccountsTable.id, { onDelete: "cascade" }),
    objectPath: text("object_path").notNull(),
    expectedSize: integer("expected_size").notNull(),
    expiresAt: timestamp("expires_at", { withTimezone: true }).notNull(),
    consumedAt: timestamp("consumed_at", { withTimezone: true }),
    createdAt: timestamp("created_at", { withTimezone: true })
      .notNull()
      .defaultNow(),
  },
  (table) => [
    uniqueIndex("liora_receipt_upload_slots_object_path_idx").on(table.objectPath),
    index("liora_receipt_upload_slots_account_expiry_idx").on(
      table.accountId,
      table.expiresAt,
    ),
  ],
);

export const lioraPaymentReceiptsTable = pgTable(
  "liora_payment_receipts",
  {
    id: text("id").primaryKey(),
    paymentAttemptId: text("payment_attempt_id")
      .notNull()
      .references(() => lioraPaymentAttemptsTable.id, { onDelete: "cascade" }),
    accountId: text("account_id")
      .notNull()
      .references(() => lioraAccountsTable.id, { onDelete: "cascade" }),
    uploadId: text("upload_id")
      .notNull()
      .references(() => lioraReceiptUploadSlotsTable.id, { onDelete: "restrict" }),
    objectPath: text("object_path").notNull(),
    declaredAmount: numeric("declared_amount", { precision: 14, scale: 2 }).notNull(),
    declaredCurrency: varchar("declared_currency", { length: 3 }).notNull(),
    payerName: varchar("payer_name", { length: 120 }).notNull(),
    description: varchar("description", { length: 500 }).notNull(),
    mimeType: varchar("mime_type", { length: 64 }).notNull(),
    fileSize: integer("file_size").notNull(),
    revision: integer("revision").notNull(),
    status: varchar("status", { length: 32 }).notNull().default("awaiting_review"),
    reviewedByAdminId: text("reviewed_by_admin_id").references(
      () => lioraAdminUsersTable.id,
      { onDelete: "set null" },
    ),
    reviewReason: text("review_reason"),
    submittedAt: timestamp("submitted_at", { withTimezone: true })
      .notNull()
      .defaultNow(),
    reviewedAt: timestamp("reviewed_at", { withTimezone: true }),
  },
  (table) => [
    uniqueIndex("liora_payment_receipts_object_path_idx").on(table.objectPath),
    uniqueIndex("liora_payment_receipts_upload_id_idx").on(table.uploadId),
    uniqueIndex("liora_payment_receipts_attempt_revision_idx").on(
      table.paymentAttemptId,
      table.revision,
    ),
    index("liora_payment_receipts_status_submitted_idx").on(
      table.status,
      table.submittedAt,
    ),
    index("liora_payment_receipts_account_idx").on(table.accountId),
    check(
      "liora_payment_receipts_valid_file_size",
      sql`${table.fileSize} > 0 AND ${table.fileSize} <= 8388608`,
    ),
  ],
);

export const lioraAdminPaymentActivityTable = pgTable(
  "liora_admin_payment_activity",
  {
    id: text("id").primaryKey(),
    actionKey: varchar("action_key", { length: 220 }).notNull(),
    paymentAttemptId: text("payment_attempt_id").references(
      () => lioraPaymentAttemptsTable.id,
      { onDelete: "cascade" },
    ),
    accountId: text("account_id").references(() => lioraAccountsTable.id, {
      onDelete: "cascade",
    }),
    adminId: text("admin_id").references(() => lioraAdminUsersTable.id, {
      onDelete: "set null",
    }),
    actorType: varchar("actor_type", { length: 24 }).notNull(),
    actorName: varchar("actor_name", { length: 120 }).notNull(),
    action: varchar("action", { length: 48 }).notNull(),
    previousStatus: varchar("previous_status", { length: 32 }),
    newStatus: varchar("new_status", { length: 32 }),
    reason: text("reason"),
    createdAt: timestamp("created_at", { withTimezone: true })
      .notNull()
      .defaultNow(),
  },
  (table) => [
    uniqueIndex("liora_admin_payment_activity_action_key_idx").on(table.actionKey),
    index("liora_admin_payment_activity_payment_created_idx").on(
      table.paymentAttemptId,
      table.createdAt,
    ),
    index("liora_admin_payment_activity_account_created_idx").on(
      table.accountId,
      table.createdAt,
    ),
    index("liora_admin_payment_activity_created_idx").on(table.createdAt),
  ],
);

export const lioraPaymentNotificationsTable = pgTable(
  "liora_payment_notifications",
  {
    id: text("id").primaryKey(),
    eventKey: varchar("event_key", { length: 200 }).notNull(),
    recipientType: varchar("recipient_type", { length: 16 }).notNull(),
    accountId: text("account_id")
      .notNull()
      .references(() => lioraAccountsTable.id, { onDelete: "cascade" }),
    recipientAdminId: text("recipient_admin_id").references(
      () => lioraAdminUsersTable.id,
      { onDelete: "cascade" },
    ),
    paymentAttemptId: text("payment_attempt_id").references(
      () => lioraPaymentAttemptsTable.id,
      { onDelete: "cascade" },
    ),
    event: varchar("event", { length: 64 }).notNull(),
    title: varchar("title", { length: 160 }).notNull(),
    message: text("message").notNull(),
    emailDeliveryStatus: varchar("email_delivery_status", { length: 24 })
      .notNull()
      .default("unavailable"),
    createdAt: timestamp("created_at", { withTimezone: true })
      .notNull()
      .defaultNow(),
    readAt: timestamp("read_at", { withTimezone: true }),
  },
  (table) => [
    uniqueIndex("liora_payment_notifications_event_key_idx").on(table.eventKey),
    index("liora_payment_notifications_admin_unread_idx").on(
      table.recipientAdminId,
      table.readAt,
      table.createdAt,
    ),
    index("liora_payment_notifications_member_unread_idx").on(
      table.accountId,
      table.recipientType,
      table.readAt,
      table.createdAt,
    ),
    check(
      "liora_payment_notifications_recipient_type_check",
      sql`(${table.recipientType} = 'admin' AND ${table.recipientAdminId} IS NOT NULL) OR (${table.recipientType} = 'member' AND ${table.recipientAdminId} IS NULL)`,
    ),
  ],
);
