import { createInsertSchema } from "drizzle-zod";
import { boolean, check, index, jsonb, pgTable, text, timestamp, uniqueIndex, varchar } from "drizzle-orm/pg-core";
import { sql } from "drizzle-orm";
import { z } from "zod/v4";
import { lioraAdminUsersTable } from "./liora-admin";
import { lioraAccountsTable } from "./liora-accounts";

export const lioraPushNotificationAuditTable = pgTable(
  "liora_push_notification_audit",
  {
    id: text("id").primaryKey(),
    requestId: varchar("request_id", { length: 36 }).notNull(),
    adminId: text("admin_id").references(() => lioraAdminUsersTable.id, { onDelete: "set null" }),
    adminName: varchar("admin_name", { length: 120 }).notNull(),
    title: varchar("title", { length: 80 }).notNull(),
    message: varchar("message", { length: 500 }).notNull(),
    segment: varchar("segment", { length: 120 }).notNull(),
    launchUrl: text("launch_url").notNull(),
    reason: varchar("reason", { length: 500 }).notNull(),
    status: varchar("status", { length: 20 }).notNull().default("pending"),
    providerMessageId: varchar("provider_message_id", { length: 100 }),
    errorCode: varchar("error_code", { length: 80 }),
    audienceIds: jsonb("audience_ids").$type<string[]>().notNull().default([]),
    providerResult: jsonb("provider_result").$type<{
      batches: Array<{ key: string; id?: string; accepted?: number; error?: string }>;
      delivery?: { accepted: number; successful: number; failed: number; errored: number; remaining: number; confirmed: number };
    }>().notNull().default({ batches: [] }),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
    updatedAt: timestamp("updated_at", { withTimezone: true })
      .notNull()
      .defaultNow()
      .$onUpdate(() => new Date()),
  },
  (table) => [
    check(
      "liora_push_notification_audit_status_check",
      sql`${table.status} IN ('pending', 'sent', 'failed')`,
    ),
    uniqueIndex("liora_push_notification_audit_request_id_idx").on(table.requestId),
    uniqueIndex("liora_push_notification_audit_provider_id_idx").on(table.providerMessageId),
    index("liora_push_notification_audit_created_idx").on(table.createdAt),
    index("liora_push_notification_audit_admin_created_idx").on(table.adminId, table.createdAt),
  ],
);

export const lioraPushMemberPreferencesTable = pgTable(
  "liora_push_member_preferences",
  {
    accountId: text("account_id")
      .primaryKey()
      .references(() => lioraAccountsTable.id, { onDelete: "cascade" }),
    consentStatus: varchar("consent_status", { length: 20 }).notNull().default("not_requested"),
    permissionStatus: varchar("permission_status", { length: 20 }).notNull().default("default"),
    consentSource: varchar("consent_source", { length: 32 }).notNull().default("settings"),
    invitationDismissed: boolean("invitation_dismissed").notNull().default(false),
    updatedAt: timestamp("updated_at", { withTimezone: true })
      .notNull()
      .defaultNow()
      .$onUpdate(() => new Date()),
  },
  (table) => [
    check(
      "liora_push_member_preferences_consent_check",
      sql`${table.consentStatus} IN ('not_requested', 'enabled', 'declined')`,
    ),
    check(
      "liora_push_member_preferences_permission_check",
      sql`${table.permissionStatus} IN ('default', 'granted', 'denied', 'unsupported')`,
    ),
    index("liora_push_member_preferences_status_idx").on(table.consentStatus, table.updatedAt),
  ],
);

export const lioraPushDeviceSubscriptionsTable = pgTable(
  "liora_push_device_subscriptions",
  {
    oneSignalSubscriptionId: varchar("onesignal_subscription_id", { length: 36 }).primaryKey(),
    accountId: text("account_id")
      .notNull()
      .references(() => lioraAccountsTable.id, { onDelete: "cascade" }),
    oneSignalUserId: varchar("onesignal_user_id", { length: 36 }),
    status: varchar("status", { length: 20 }).notNull().default("active"),
    platform: varchar("platform", { length: 24 }).notNull().default("web"),
    firstSeenAt: timestamp("first_seen_at", { withTimezone: true }).notNull().defaultNow(),
    lastSyncedAt: timestamp("last_synced_at", { withTimezone: true }).notNull().defaultNow(),
    updatedAt: timestamp("updated_at", { withTimezone: true })
      .notNull()
      .defaultNow()
      .$onUpdate(() => new Date()),
  },
  (table) => [
    check(
      "liora_push_device_subscriptions_status_check",
      sql`${table.status} IN ('active', 'unsubscribed', 'expired')`,
    ),
    index("liora_push_device_subscriptions_account_status_idx").on(table.accountId, table.status),
    index("liora_push_device_subscriptions_synced_idx").on(table.lastSyncedAt),
  ],
);

export const insertLioraPushNotificationAuditSchema = createInsertSchema(
  lioraPushNotificationAuditTable,
).omit({ createdAt: true, updatedAt: true });

export type InsertLioraPushNotificationAudit = z.infer<
  typeof insertLioraPushNotificationAuditSchema
>;
export type LioraPushNotificationAudit =
  typeof lioraPushNotificationAuditTable.$inferSelect;
export type LioraPushMemberPreference =
  typeof lioraPushMemberPreferencesTable.$inferSelect;
export type LioraPushDeviceSubscription =
  typeof lioraPushDeviceSubscriptionsTable.$inferSelect;

// Admin devices are deliberately separate: they can never enter member broadcasts.
export const lioraPushAdminDevicesTable = pgTable("liora_push_admin_devices", {
  subscriptionId: varchar("subscription_id", { length: 36 }).primaryKey(),
  adminId: text("admin_id").notNull().references(() => lioraAdminUsersTable.id, { onDelete: "cascade" }),
  status: varchar("status", { length: 20 }).notNull().default("active"),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
}, (table) => [
  check("liora_push_admin_device_status_check", sql`${table.status} IN ('active', 'unsubscribed', 'expired')`),
  index("liora_push_admin_device_owner_idx").on(table.adminId, table.status),
]);
