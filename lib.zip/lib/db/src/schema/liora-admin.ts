import {
  index,
  pgTable,
  text,
  timestamp,
  uniqueIndex,
  varchar,
} from "drizzle-orm/pg-core";

export const lioraAdminUsersTable = pgTable(
  "liora_admin_users",
  {
    id: text("id").primaryKey(),
    email: varchar("email", { length: 254 }).notNull(),
    username: varchar("username", { length: 32 }).notNull(),
    displayName: varchar("display_name", { length: 120 }).notNull(),
    passwordHash: text("password_hash").notNull(),
    role: varchar("role", { length: 24 }).notNull().default("admin"),
    status: varchar("status", { length: 24 }).notNull().default("active"),
    lastLoginAt: timestamp("last_login_at", { withTimezone: true }),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
    updatedAt: timestamp("updated_at", { withTimezone: true })
      .notNull()
      .defaultNow()
      .$onUpdate(() => new Date()),
  },
  (table) => [
    uniqueIndex("liora_admin_users_email_idx").on(table.email),
    uniqueIndex("liora_admin_users_username_idx").on(table.username),
    index("liora_admin_users_role_idx").on(table.role),
  ],
);

export const lioraAdminSessionsTable = pgTable(
  "liora_admin_sessions",
  {
    tokenHash: text("token_hash").primaryKey(),
    adminId: text("admin_id")
      .notNull()
      .references(() => lioraAdminUsersTable.id, { onDelete: "cascade" }),
    expiresAt: timestamp("expires_at", { withTimezone: true }).notNull(),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [index("liora_admin_sessions_admin_idx").on(table.adminId)],
);

export const lioraAdminPasswordResetTokensTable = pgTable(
  "liora_admin_password_reset_tokens",
  {
    tokenHash: text("token_hash").primaryKey(),
    adminId: text("admin_id")
      .notNull()
      .references(() => lioraAdminUsersTable.id, { onDelete: "cascade" }),
    expiresAt: timestamp("expires_at", { withTimezone: true }).notNull(),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [index("liora_admin_password_reset_admin_idx").on(table.adminId)],
);

export type LioraAdminUser = typeof lioraAdminUsersTable.$inferSelect;
export type LioraAdminSession = typeof lioraAdminSessionsTable.$inferSelect;
