import {
  boolean,
  index,
  numeric,
  pgTable,
  text,
  timestamp,
  uniqueIndex,
  varchar,
} from "drizzle-orm/pg-core";
import { sql } from "drizzle-orm";

export const lioraAccountsTable = pgTable(
  "liora_accounts",
  {
    id: text("id").primaryKey(),
    fullName: varchar("full_name", { length: 120 }).notNull(),
    username: varchar("username", { length: 24 }).notNull(),
    email: varchar("email", { length: 254 }).notNull(),
    phoneNumber: varchar("phone_number", { length: 32 }).notNull(),
    country: varchar("country", { length: 80 }).notNull(),
    passwordHash: text("password_hash").notNull(),
    status: varchar("status", { length: 32 }).notNull().default("pending_payment"),
    paymentStatus: varchar("payment_status", { length: 32 }).notNull().default("pending"),
    lioraKey: varchar("liora_key", { length: 40 }),
    registrationAmount: numeric("registration_amount", { precision: 14, scale: 2 }).notNull(),
    currency: varchar("currency", { length: 3 }).notNull(),
    welcomeBonusAmount: numeric("welcome_bonus_amount", { precision: 14, scale: 2 }).notNull(),
    welcomeBonusCreditStatus: varchar("welcome_bonus_credit_status", { length: 32 })
      .notNull()
      .default("pending"),
    termsAcceptedAt: timestamp("terms_accepted_at", { withTimezone: true }).notNull(),
    privacyAcceptedAt: timestamp("privacy_accepted_at", { withTimezone: true }).notNull(),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
    activatedAt: timestamp("activated_at", { withTimezone: true }),
  },
  (table) => [
    uniqueIndex("liora_accounts_username_lower_idx").on(table.username),
    uniqueIndex("liora_accounts_email_lower_idx").on(table.email),
    uniqueIndex("liora_accounts_liora_key_idx").on(table.lioraKey),
    index("liora_accounts_status_idx").on(table.status),
    index("liora_accounts_payment_account_status_idx").on(table.paymentStatus, table.status),
    index("liora_accounts_country_idx").on(table.country),
    index("liora_accounts_created_at_idx").on(table.createdAt),
    index("liora_accounts_activated_at_idx").on(table.activatedAt),
  ],
);

export const lioraPaymentAttemptsTable = pgTable(
  "liora_payment_attempts",
  {
    id: text("id").primaryKey(),
    accountId: text("account_id")
      .notNull()
      .references(() => lioraAccountsTable.id, { onDelete: "cascade" }),
    transactionReference: varchar("transaction_reference", { length: 100 }).notNull(),
    providerTransactionId: varchar("provider_transaction_id", { length: 100 }),
    amount: numeric("amount", { precision: 14, scale: 2 }).notNull(),
    currency: varchar("currency", { length: 3 }).notNull(),
    status: varchar("status", { length: 32 }).notNull().default("pending"),
    paymentMethod: varchar("payment_method", { length: 32 })
      .notNull()
      .default("flutterwave"),
    bankAccountId: text("bank_account_id"),
    bankNameSnapshot: varchar("bank_name_snapshot", { length: 120 }),
    bankAccountNameSnapshot: varchar("bank_account_name_snapshot", { length: 120 }),
    bankAccountNumberSnapshot: varchar("bank_account_number_snapshot", { length: 64 }),
    bankBranchSnapshot: varchar("bank_branch_snapshot", { length: 120 }),
    bankSwiftBicSnapshot: varchar("bank_swift_bic_snapshot", { length: 20 }),
    bankIbanSnapshot: varchar("bank_iban_snapshot", { length: 34 }),
    bankInstructionsSnapshot: text("bank_instructions_snapshot"),
    checkoutUrl: text("checkout_url"),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
    verifiedAt: timestamp("verified_at", { withTimezone: true }),
  },
  (table) => [
    uniqueIndex("liora_payment_attempts_tx_ref_idx").on(table.transactionReference),
    uniqueIndex("liora_payment_attempts_provider_id_idx").on(table.providerTransactionId),
    index("liora_payment_attempts_account_idx").on(table.accountId),
    index("liora_payment_attempts_status_verified_at_idx").on(table.status, table.verifiedAt),
    uniqueIndex("liora_payment_attempts_active_manual_account_idx")
      .on(table.accountId)
      .where(
        sql`${table.paymentMethod} = 'bank_transfer' AND ${table.status} IN ('pending', 'awaiting_receipt_review', 'rejected')`,
      ),
  ],
);

export const lioraSessionsTable = pgTable(
  "liora_sessions",
  {
    tokenHash: text("token_hash").primaryKey(),
    accountId: text("account_id")
      .notNull()
      .references(() => lioraAccountsTable.id, { onDelete: "cascade" }),
    expiresAt: timestamp("expires_at", { withTimezone: true }).notNull(),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [index("liora_sessions_account_idx").on(table.accountId)],
);

export const lioraPasswordResetTokensTable = pgTable(
  "liora_password_reset_tokens",
  {
    tokenHash: text("token_hash").primaryKey(),
    accountId: text("account_id")
      .notNull()
      .references(() => lioraAccountsTable.id, { onDelete: "cascade" }),
    expiresAt: timestamp("expires_at", { withTimezone: true }).notNull(),
    usedAt: timestamp("used_at", { withTimezone: true }),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [index("liora_password_reset_account_idx").on(table.accountId)],
);

export const lioraWelcomeBonusCreditsTable = pgTable(
  "liora_welcome_bonus_credits",
  {
    id: text("id").primaryKey(),
    accountId: text("account_id")
      .notNull()
      .references(() => lioraAccountsTable.id, { onDelete: "cascade" }),
    amount: numeric("amount", { precision: 14, scale: 2 }).notNull(),
    currency: varchar("currency", { length: 3 }).notNull(),
    creditedAt: timestamp("credited_at", { withTimezone: true }).notNull().defaultNow(),
    confirmed: boolean("confirmed").notNull().default(false),
  },
  (table) => [uniqueIndex("liora_welcome_bonus_account_idx").on(table.accountId)],
);
