import { sql } from "drizzle-orm";
import {
  check,
  index,
  integer,
  jsonb,
  pgTable,
  text,
  timestamp,
  uniqueIndex,
  varchar,
} from "drizzle-orm/pg-core";
import { lioraAdminUsersTable } from "./liora-admin";

export type WebsiteContentType =
  | "about"
  | "testimonials"
  | "faq"
  | "contact"
  | "social-links";

export type AboutPageContent = {
  hero: {
    eyebrow: string;
    headline: string;
    headlineEmphasis: string;
    supportingDescription: string;
    tagline: string;
    closingEyebrow: string;
    closingHeading: string;
    closingHeadingEmphasis: string;
    closingDescription: string;
  };
  sections: Array<{
    id: string;
    kind: "intro" | "story" | "ecosystem" | "steps" | "principles" | "vision" | "statistics" | "registration" | "social" | "prose";
    eyebrow: string;
    heading: string;
    headingEmphasis: string;
    description: string;
    paragraphs: string[];
    items: Array<{ id: string; title: string; description: string; note: string }>;
  }>;
};

export type AboutPageSection = AboutPageContent["sections"][number];
export type AboutPageSectionItem = AboutPageSection["items"][number];

export type ManagedTestimonial = {
  id: string;
  name: string;
  memberSince: string;
  quote: string;
  photo: string;
  rating: number | null;
  status: "pending" | "approved" | "rejected";
  displayOrder: number;
};

export type TestimonialsPageContent = { items: ManagedTestimonial[] };

export type ManagedFaqItem = {
  id: string;
  question: string;
  answer: string[];
  steps?: string[];
  closing?: string[];
  countries?: string[];
  link?: { label: string; href: string };
};

export type ManagedFaqCategory = {
  id: string;
  title: string;
  items: ManagedFaqItem[];
};

export type FaqPageContent = {
  pageTitle: string;
  description: string;
  categories: ManagedFaqCategory[];
};

export type SocialPlatform =
  | "instagram"
  | "facebook"
  | "tiktok"
  | "telegram"
  | "youtube"
  | "x"
  | "whatsapp";

export type ManagedSocialLink = {
  id: string;
  platform: SocialPlatform;
  label: string;
  url: string;
  enabled: boolean;
  displayOrder: number;
  placements: {
    header: boolean;
    contact: boolean;
    footer: boolean;
  };
};

export type SocialLinksContent = { links: ManagedSocialLink[] };

export type ContactMethod = {
  id: string;
  label: string;
  details: string;
  action: string;
  group: "support" | "community" | "other";
  socialLinkId: string;
  url: string;
  enabled: boolean;
  displayOrder: number;
};

export type ContactPageContent = {
  heroEyebrow: string;
  heroTitle: string;
  heroEmphasis: string;
  heroDescription: string;
  connectEyebrow: string;
  connectTitle: string;
  connectDescription: string;
  supportGroupTitle: string;
  supportGroupDescription: string;
  communityGroupTitle: string;
  communityGroupDescription: string;
  otherGroupTitle: string;
  otherGroupDescription: string;
  supportEmail: string;
  showSupportEmail: boolean;
  emailDisplayOrder: number;
  methods: ContactMethod[];
  closingEyebrow: string;
  closingTitle: string;
  closingEmphasis: string;
};

export type WebsiteContent =
  | AboutPageContent
  | TestimonialsPageContent
  | FaqPageContent
  | ContactPageContent
  | SocialLinksContent;

export const lioraWebsiteContentVersionsTable = pgTable(
  "liora_website_content_versions",
  {
    id: text("id").primaryKey(),
    contentType: varchar("content_type", { length: 24 }).notNull(),
    version: integer("version").notNull(),
    status: varchar("status", { length: 16 }).notNull(),
    content: jsonb("content").$type<WebsiteContent>().notNull(),
    createdByAdminId: text("created_by_admin_id").references(() => lioraAdminUsersTable.id, { onDelete: "set null" }),
    updatedByAdminId: text("updated_by_admin_id").references(() => lioraAdminUsersTable.id, { onDelete: "set null" }),
    publishedByAdminId: text("published_by_admin_id").references(() => lioraAdminUsersTable.id, { onDelete: "set null" }),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
    updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
    publishedAt: timestamp("published_at", { withTimezone: true }),
  },
  (table) => [
    check("liora_website_content_type_check", sql`${table.contentType} in ('about', 'testimonials', 'faq', 'contact', 'social-links')`),
    check("liora_website_content_status_check", sql`${table.status} in ('draft', 'published', 'archived', 'discarded')`),
    check("liora_website_content_version_check", sql`${table.version} > 0`),
    uniqueIndex("liora_website_content_type_version_unique").on(table.contentType, table.version),
    uniqueIndex("liora_website_content_one_draft_idx").on(table.contentType).where(sql`${table.status} = 'draft'`),
    uniqueIndex("liora_website_content_one_published_idx").on(table.contentType).where(sql`${table.status} = 'published'`),
    index("liora_website_content_type_status_updated_idx").on(table.contentType, table.status, table.updatedAt),
  ],
);

export const lioraWebsiteContentAuditTable = pgTable(
  "liora_website_content_audit",
  {
    id: text("id").primaryKey(),
    contentType: varchar("content_type", { length: 24 }).notNull(),
    adminId: text("admin_id").references(() => lioraAdminUsersTable.id, { onDelete: "set null" }),
    action: varchar("action", { length: 32 }).notNull(),
    versionId: text("version_id").references(() => lioraWebsiteContentVersionsTable.id, { onDelete: "set null" }),
    version: integer("version").notNull(),
    details: jsonb("details").$type<Record<string, unknown>>().notNull().default({}),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [
    check("liora_website_content_audit_type_check", sql`${table.contentType} in ('about', 'testimonials', 'faq', 'contact', 'social-links')`),
    index("liora_website_content_audit_admin_created_idx").on(table.adminId, table.createdAt),
    index("liora_website_content_audit_type_created_idx").on(table.contentType, table.createdAt),
    index("liora_website_content_audit_version_created_idx").on(table.versionId, table.createdAt),
    index("liora_website_content_audit_created_idx").on(table.createdAt),
  ],
);

export type LioraWebsiteContentVersion = typeof lioraWebsiteContentVersionsTable.$inferSelect;
export type LioraWebsiteContentAudit = typeof lioraWebsiteContentAuditTable.$inferSelect;
