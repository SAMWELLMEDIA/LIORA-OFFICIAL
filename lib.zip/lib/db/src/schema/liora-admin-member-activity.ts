import { index, pgTable, text, timestamp, varchar } from "drizzle-orm/pg-core";
import { lioraAccountsTable } from "./liora-accounts";
import { lioraAdminUsersTable } from "./liora-admin";

export const lioraAdminMemberActivityTable = pgTable(
  "liora_admin_member_activity",
  {
    id: text("id").primaryKey(),
    adminId: text("admin_id")
      .notNull()
      .references(() => lioraAdminUsersTable.id, { onDelete: "restrict" }),
    adminName: varchar("admin_name", { length: 120 }).notNull(),
    accountId: text("account_id")
      .notNull()
      .references(() => lioraAccountsTable.id, { onDelete: "restrict" }),
    action: varchar("action", { length: 40 }).notNull(),
    previousStatus: varchar("previous_status", { length: 32 }).notNull(),
    newStatus: varchar("new_status", { length: 32 }).notNull(),
    reason: varchar("reason", { length: 500 }).notNull(),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [
    index("liora_admin_member_activity_account_created_idx").on(table.accountId, table.createdAt),
    index("liora_admin_member_activity_admin_created_idx").on(table.adminId, table.createdAt),
    index("liora_admin_member_activity_created_idx").on(table.createdAt),
  ],
);

export type LioraAdminMemberActivity = typeof lioraAdminMemberActivityTable.$inferSelect;
