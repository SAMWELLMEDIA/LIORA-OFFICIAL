import { createInsertSchema } from "drizzle-zod";
import {
  boolean,
  check,
  index,
  integer,
  jsonb,
  pgTable,
  text,
  timestamp,
  uniqueIndex,
  varchar,
} from "drizzle-orm/pg-core";
import { sql } from "drizzle-orm";
import { z } from "zod/v4";
import { lioraAccountsTable } from "./liora-accounts";
import { lioraAdminUsersTable } from "./liora-admin";

export const lioraEmailTemplatesTable = pgTable(
  "liora_email_templates",
  {
    id: text("id").primaryKey(),
    name: varchar("name", { length: 120 }).notNull(),
    subject: varchar("subject", { length: 250 }).notNull(),
    htmlContent: text("html_content").notNull(),
    status: varchar("status", { length: 16 }).notNull().default("inactive"),
    createdByAdminId: text("created_by_admin_id").references(
      () => lioraAdminUsersTable.id,
      { onDelete: "set null" },
    ),
    updatedByAdminId: text("updated_by_admin_id").references(
      () => lioraAdminUsersTable.id,
      { onDelete: "set null" },
    ),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
    updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
    archivedAt: timestamp("archived_at", { withTimezone: true }),
  },
  (table) => [
    check("liora_email_templates_status_check", sql`${table.status} IN ('active', 'inactive', 'archived')`),
    index("liora_email_templates_status_updated_idx").on(table.status, table.updatedAt),
  ],
);

export const lioraEmailCampaignsTable = pgTable(
  "liora_email_campaigns",
  {
    id: text("id").primaryKey(),
    name: varchar("name", { length: 140 }).notNull(),
    templateId: text("template_id").references(
      () => lioraEmailTemplatesTable.id,
      { onDelete: "set null" },
    ),
    templateNameSnapshot: varchar("template_name_snapshot", { length: 120 }).notNull(),
    subjectSnapshot: varchar("subject_snapshot", { length: 250 }).notNull(),
    htmlSnapshot: text("html_snapshot").notNull(),
    recipientFilters: jsonb("recipient_filters").$type<Record<string, unknown>>().notNull().default({}),
    status: varchar("status", { length: 20 }).notNull().default("draft"),
    scheduledAt: timestamp("scheduled_at", { withTimezone: true }),
    startedAt: timestamp("started_at", { withTimezone: true }),
    completedAt: timestamp("completed_at", { withTimezone: true }),
    cancelledAt: timestamp("cancelled_at", { withTimezone: true }),
    targetCount: integer("target_count").notNull().default(0),
    createdByAdminId: text("created_by_admin_id").references(
      () => lioraAdminUsersTable.id,
      { onDelete: "set null" },
    ),
    updatedByAdminId: text("updated_by_admin_id").references(
      () => lioraAdminUsersTable.id,
      { onDelete: "set null" },
    ),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
    updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [
    check(
      "liora_email_campaigns_status_check",
      sql`${table.status} IN ('draft', 'scheduled', 'queued', 'sending', 'sent', 'partial_failed', 'failed', 'cancelled')`,
    ),
    check("liora_email_campaigns_target_count_check", sql`${table.targetCount} >= 0`),
    index("liora_email_campaigns_status_schedule_idx").on(table.status, table.scheduledAt),
    index("liora_email_campaigns_created_idx").on(table.createdAt),
  ],
);

export const lioraEmailPreferencesTable = pgTable(
  "liora_email_preferences",
  {
    accountId: text("account_id")
      .primaryKey()
      .references(() => lioraAccountsTable.id, { onDelete: "cascade" }),
    marketingConsent: boolean("marketing_consent").notNull().default(false),
    consentedAt: timestamp("consented_at", { withTimezone: true }),
    consentSource: varchar("consent_source", { length: 32 }),
    unsubscribedAt: timestamp("unsubscribed_at", { withTimezone: true }),
    updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [
    check(
      "liora_email_preferences_consent_state_check",
      sql`(${table.marketingConsent} = true AND ${table.consentedAt} IS NOT NULL) OR (${table.marketingConsent} = false)`,
    ),
    index("liora_email_preferences_consent_idx").on(table.marketingConsent, table.unsubscribedAt),
  ],
);

export const lioraEmailSuppressionsTable = pgTable(
  "liora_email_suppressions",
  {
    email: varchar("email", { length: 254 }).primaryKey(),
    reason: varchar("reason", { length: 32 }).notNull(),
    source: varchar("source", { length: 32 }).notNull(),
    providerEventId: varchar("provider_event_id", { length: 100 }),
    addedAt: timestamp("added_at", { withTimezone: true }).notNull().defaultNow(),
    updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [
    check(
      "liora_email_suppressions_reason_check",
      sql`${table.reason} IN ('unsubscribe', 'hard_bounce', 'complaint', 'invalid', 'provider_suppression')`,
    ),
    index("liora_email_suppressions_updated_idx").on(table.updatedAt),
  ],
);

export const lioraEmailCampaignRecipientsTable = pgTable(
  "liora_email_campaign_recipients",
  {
    id: text("id").primaryKey(),
    campaignId: text("campaign_id")
      .notNull()
      .references(() => lioraEmailCampaignsTable.id, { onDelete: "cascade" }),
    accountId: text("account_id").references(() => lioraAccountsTable.id, { onDelete: "set null" }),
    emailSnapshot: varchar("email_snapshot", { length: 254 }).notNull(),
    variablesSnapshot: jsonb("variables_snapshot").$type<Record<string, string>>().notNull(),
    status: varchar("status", { length: 20 }).notNull().default("queued"),
    attemptCount: integer("attempt_count").notNull().default(0),
    nextAttemptAt: timestamp("next_attempt_at", { withTimezone: true }).notNull().defaultNow(),
    processingStartedAt: timestamp("processing_started_at", { withTimezone: true }),
    providerEmailId: varchar("provider_email_id", { length: 100 }),
    lastError: varchar("last_error", { length: 200 }),
    lastProviderEvent: varchar("last_provider_event", { length: 40 }),
    acceptedAt: timestamp("accepted_at", { withTimezone: true }),
    deliveredAt: timestamp("delivered_at", { withTimezone: true }),
    completedAt: timestamp("completed_at", { withTimezone: true }),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
    updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [
    check(
      "liora_email_campaign_recipients_status_check",
      sql`${table.status} IN ('queued', 'sending', 'sent', 'delivered', 'bounced', 'complained', 'failed', 'cancelled', 'suppressed')`,
    ),
    check("liora_email_campaign_recipients_attempts_check", sql`${table.attemptCount} >= 0`),
    uniqueIndex("liora_email_campaign_recipient_account_unique").on(table.campaignId, table.accountId),
    uniqueIndex("liora_email_campaign_recipient_email_unique").on(table.campaignId, table.emailSnapshot),
    uniqueIndex("liora_email_campaign_provider_email_unique").on(table.providerEmailId),
    index("liora_email_campaign_recipient_queue_idx").on(table.status, table.nextAttemptAt),
    index("liora_email_campaign_recipient_campaign_idx").on(table.campaignId, table.status),
  ],
);

export const lioraEmailWebhookEventsTable = pgTable(
  "liora_email_webhook_events",
  {
    id: varchar("id", { length: 100 }).primaryKey(),
    eventType: varchar("event_type", { length: 50 }).notNull(),
    providerEmailId: varchar("provider_email_id", { length: 100 }),
    processedAt: timestamp("processed_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [index("liora_email_webhook_type_processed_idx").on(table.eventType, table.processedAt)],
);

export const lioraEmailAdminAuditTable = pgTable(
  "liora_email_admin_audit",
  {
    id: text("id").primaryKey(),
    adminId: text("admin_id").references(() => lioraAdminUsersTable.id, { onDelete: "set null" }),
    action: varchar("action", { length: 40 }).notNull(),
    resourceType: varchar("resource_type", { length: 24 }).notNull(),
    resourceId: text("resource_id"),
    details: jsonb("details").$type<Record<string, unknown>>().notNull().default({}),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [
    index("liora_email_admin_audit_admin_created_idx").on(table.adminId, table.createdAt),
    index("liora_email_admin_audit_resource_idx").on(table.resourceType, table.resourceId, table.createdAt),
    index("liora_email_admin_audit_created_idx").on(table.createdAt),
  ],
);

export const insertEmailTemplateSchema = createInsertSchema(lioraEmailTemplatesTable).omit({
  createdAt: true,
  updatedAt: true,
  archivedAt: true,
});
export type EmailTemplate = typeof lioraEmailTemplatesTable.$inferSelect;
export type EmailCampaign = typeof lioraEmailCampaignsTable.$inferSelect;
export type EmailCampaignRecipient = typeof lioraEmailCampaignRecipientsTable.$inferSelect;
export type EmailPreference = typeof lioraEmailPreferencesTable.$inferSelect;
export type InsertEmailTemplate = z.infer<typeof insertEmailTemplateSchema>;
