import { date, index, pgTable, primaryKey, timestamp, text } from "drizzle-orm/pg-core";

/**
 * One pseudonymous record per first-party browser identifier per Lagos day.
 * Raw browser identifiers, IP addresses, user agents and page paths are not stored.
 */
export const lioraVisitorDailyTable = pgTable(
  "liora_visitor_daily",
  {
    visitorHash: text("visitor_hash").notNull(),
    visitDate: date("visit_date", { mode: "string" }).notNull(),
    firstSeenAt: timestamp("first_seen_at", { withTimezone: true }).notNull().defaultNow(),
    lastSeenAt: timestamp("last_seen_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [
    primaryKey({ columns: [table.visitorHash, table.visitDate] }),
    index("liora_visitor_daily_date_idx").on(table.visitDate),
  ],
);

export type LioraVisitorDaily = typeof lioraVisitorDailyTable.$inferSelect;
