import {
  check,
  index,
  integer,
  jsonb,
  pgTable,
  text,
  timestamp,
  uniqueIndex,
  varchar,
} from "drizzle-orm/pg-core";
import { sql } from "drizzle-orm";
import { lioraAdminUsersTable } from "./liora-admin";

export type HomepageContentLink = {
  label: string;
  href: string;
  group: "explore" | "connect";
};

export type HomepageSocialLink = {
  label: string;
  href: string;
  platform: "whatsapp" | "telegram" | "tiktok" | "youtube" | "other";
};

export type HomepageContent = {
  hero: {
    eyebrow: string;
    headline: string;
    headlineEmphasis: string;
    supportingDescription: string;
    tagline: string;
    primaryCtaText: string;
    primaryCtaDestination: string;
    secondaryCtaText: string;
    secondaryCtaDestination: string | null;
    imagePath: string;
    imageAlt: string;
  };
  introduction: {
    eyebrow: string;
    heading: string;
    description: string;
    supportingText: string;
  };
  ecosystem: {
    pillars: Array<{
      id: string;
      title: string;
      description: string;
      icon: "none" | "sparkles" | "lightbulb" | "users" | "compass";
    }>;
  };
  whyChoose: {
    heading: string;
    description: string;
    features: Array<{
      id: string;
      title: string;
      description: string;
    }>;
  };
  visionMission: {
    visionHeading: string;
    visionContent: string;
    missionHeading: string;
    missionContent: string;
  };
  finalCta: {
    eyebrow: string;
    heading: string;
    headingEmphasis: string;
    supportingDescription: string;
    buttonText: string;
    destination: string;
  };
  footer: {
    brandDescription: string;
    slogan: string;
    navigationLinks: HomepageContentLink[];
    socialLinks: HomepageSocialLink[];
  };
};

export const DEFAULT_HOMEPAGE_CONTENT: HomepageContent = {
  hero: {
    eyebrow: "A connected digital ecosystem",
    headline: "Possibility,",
    headlineEmphasis: "connected.",
    supportingDescription:
      "LIORA is a digital ecosystem in development, centered on opportunities, AI training and data contribution, and community.",
    tagline: "One ecosystem. Many ways forward.",
    primaryCtaText: "Get Started",
    primaryCtaDestination: "/register",
    secondaryCtaText: "How to Earn on LIORA",
    secondaryCtaDestination: null,
    imagePath: "/brand/liora-mark.jpeg",
    imageAlt: "Official LIORA gold geometric mark on black",
  },
  introduction: {
    eyebrow: "The LIORA ecosystem",
    heading: "What You Can Access",
    description: "Three connected pillars shape LIORA’s focus.",
    supportingText: "",
  },
  ecosystem: {
    pillars: [
      {
        id: "opportunities",
        title: "Opportunities",
        description: "Discover opportunities connected to the LIORA ecosystem.",
        icon: "none",
      },
      {
        id: "ai-training",
        title: "AI Training & Data Contribution",
        description: "AI training and data contribution are a core LIORA pillar.",
        icon: "none",
      },
      {
        id: "community-ownership",
        title: "Community & Ownership",
        description: "A focus on participation and community as LIORA develops.",
        icon: "none",
      },
    ],
  },
  whyChoose: {
    heading: "Why Choose LIORA?",
    description: "Our established principles guide how the ecosystem develops.",
    features: [
      {
        id: "accessibility",
        title: "Accessibility",
        description: "Make room for more people to participate and progress.",
      },
      {
        id: "innovation",
        title: "Innovation",
        description: "Keep exploring thoughtful ways to connect people and possibility.",
      },
      {
        id: "growth",
        title: "Growth",
        description: "Create space for learning, development and new directions.",
      },
      {
        id: "community",
        title: "Community",
        description: "Build with people in mind, not just platforms and features.",
      },
      {
        id: "long-term-vision",
        title: "Long-term vision",
        description: "Choose lasting value over quick wins.",
      },
    ],
  },
  visionMission: {
    visionHeading: "",
    visionContent: "",
    missionHeading: "",
    missionContent: "",
  },
  finalCta: {
    eyebrow: "Your next step",
    heading: "Get Started with",
    headingEmphasis: "LIORA.",
    supportingDescription: "Explore the LIORA ecosystem and learn about its three pillars.",
    buttonText: "Get Started",
    destination: "/register",
  },
  footer: {
    brandDescription:
      "A developing digital ecosystem connecting opportunities, products, digital services and community.",
    slogan: "Light With Endless Opportunities.",
    navigationLinks: [
      { group: "explore", label: "About Us", href: "/about" },
      { group: "explore", label: "How It Works", href: "/how-it-works" },
      { group: "explore", label: "Our Ecosystem", href: "/about#ecosystem" },
      { group: "explore", label: "Our Vision", href: "/about#vision" },
      { group: "explore", label: "FAQ", href: "/#faq" },
      { group: "connect", label: "Contact", href: "/contact" },
      { group: "connect", label: "Get in touch", href: "/contact" },
      { group: "connect", label: "Get Started", href: "/register" },
      { group: "connect", label: "Terms & Conditions", href: "/terms-and-conditions" },
      { group: "connect", label: "Privacy Policy", href: "/privacy-policy" },
      { group: "connect", label: "Refund Policy", href: "/refund-policy" },
    ],
    socialLinks: [
      {
        label: "LIORA WhatsApp Channel",
        href: "https://whatsapp.com/channel/0029Vaqzr6eCcW4r7fxe5A3i",
        platform: "whatsapp",
      },
      {
        label: "LIORA Telegram Channel",
        href: "https://t.me/+RAYXr-kF_8pjYWRk",
        platform: "telegram",
      },
      {
        label: "LIORA Telegram Support",
        href: "https://t.me/liora_support_team",
        platform: "telegram",
      },
      {
        label: "LIORA on TikTok",
        href: "https://www.tiktok.com/@liora_official001",
        platform: "tiktok",
      },
      {
        label: "LIORA on YouTube",
        href: "https://www.youtube.com/@LIORAOFFICIAL-001",
        platform: "youtube",
      },
    ],
  },
};

export const lioraHomepageVersionsTable = pgTable(
  "liora_homepage_versions",
  {
    id: text("id").primaryKey(),
    version: integer("version").notNull(),
    status: varchar("status", { length: 24 }).notNull(),
    content: jsonb("content").$type<HomepageContent>().notNull(),
    createdByAdminId: text("created_by_admin_id").references(
      () => lioraAdminUsersTable.id,
      { onDelete: "set null" },
    ),
    updatedByAdminId: text("updated_by_admin_id").references(
      () => lioraAdminUsersTable.id,
      { onDelete: "set null" },
    ),
    publishedByAdminId: text("published_by_admin_id").references(
      () => lioraAdminUsersTable.id,
      { onDelete: "set null" },
    ),
    publishedAt: timestamp("published_at", { withTimezone: true }),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
    updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [
    check(
      "liora_homepage_versions_status_check",
      sql`${table.status} IN ('draft', 'published', 'archived', 'discarded')`,
    ),
    check("liora_homepage_versions_version_check", sql`${table.version} > 0`),
    uniqueIndex("liora_homepage_versions_version_unique").on(table.version),
    uniqueIndex("liora_homepage_versions_one_draft_idx")
      .on(table.status)
      .where(sql`${table.status} = 'draft'`),
    uniqueIndex("liora_homepage_versions_one_published_idx")
      .on(table.status)
      .where(sql`${table.status} = 'published'`),
    index("liora_homepage_versions_status_updated_idx").on(table.status, table.updatedAt),
  ],
);

export const lioraHomepageContentAuditTable = pgTable(
  "liora_homepage_content_audit",
  {
    id: text("id").primaryKey(),
    adminId: text("admin_id").references(() => lioraAdminUsersTable.id, {
      onDelete: "set null",
    }),
    action: varchar("action", { length: 32 }).notNull(),
    versionId: text("version_id").references(() => lioraHomepageVersionsTable.id, {
      onDelete: "set null",
    }),
    version: integer("version").notNull(),
    details: jsonb("details").$type<Record<string, unknown>>().notNull().default({}),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [
    index("liora_homepage_content_audit_admin_created_idx").on(table.adminId, table.createdAt),
    index("liora_homepage_content_audit_version_created_idx").on(table.version, table.createdAt),
    index("liora_homepage_content_audit_created_idx").on(table.createdAt),
  ],
);

export type LioraHomepageVersion = typeof lioraHomepageVersionsTable.$inferSelect;
export type LioraHomepageContentAudit = typeof lioraHomepageContentAuditTable.$inferSelect;
