import { createInsertSchema } from "drizzle-zod";
import {
  integer,
  pgEnum,
  pgTable,
  text,
  timestamp,
} from "drizzle-orm/pg-core";
import { z } from "zod/v4";

export const testimonialApprovalStatus = pgEnum("liora_testimonial_status", [
  "pending",
  "approved",
  "rejected",
]);

export const testimonialsTable = pgTable("liora_testimonials", {
  id: text("id").primaryKey(),
  name: text("name").notNull(),
  memberSince: text("member_since").notNull(),
  quote: text("quote").notNull(),
  photo: text("photo").notNull(),
  rating: integer("rating"),
  status: testimonialApprovalStatus("status").notNull().default("pending"),
  displayOrder: integer("display_order").notNull().default(0),
  createdAt: timestamp("created_at", { withTimezone: true })
    .notNull()
    .defaultNow(),
  approvedAt: timestamp("approved_at", { withTimezone: true }),
});

export const insertTestimonialSchema = createInsertSchema(
  testimonialsTable,
).omit({
  createdAt: true,
  approvedAt: true,
});

export type InsertTestimonial = z.infer<typeof insertTestimonialSchema>;
export type Testimonial = typeof testimonialsTable.$inferSelect;
