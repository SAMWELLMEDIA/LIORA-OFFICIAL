import { sql } from "drizzle-orm";
import {
  check,
  index,
  integer,
  jsonb,
  pgTable,
  text,
  timestamp,
  uniqueIndex,
  varchar,
} from "drizzle-orm/pg-core";
import { lioraAdminUsersTable } from "./liora-admin";

export type LioraSeoPageSettings = {
  path: string;
  title: string;
  description: string;
  canonicalUrl: string;
  openGraphTitle: string;
  openGraphDescription: string;
  openGraphImage: string;
  twitterTitle: string;
  twitterDescription: string;
  index: boolean;
  follow: boolean;
};

export type LioraSeoSettingsDocument = {
  general: {
    defaultTitle: string;
    defaultDescription: string;
    canonicalDomain: string;
    defaultOpenGraphImage: string;
    defaultSocialTitle: string;
    defaultSocialDescription: string;
  };
  pages: LioraSeoPageSettings[];
};

export type LioraSeoHistoryAction =
  | "draft_saved"
  | "published"
  | "draft_discarded"
  | "restored_as_draft";

export const lioraSeoSettingsTable = pgTable(
  "liora_seo_settings",
  {
    id: varchar("id", { length: 24 }).primaryKey(),
    draft: jsonb("draft").$type<LioraSeoSettingsDocument>(),
    published: jsonb("published").$type<LioraSeoSettingsDocument>(),
    revision: integer("revision").notNull().default(0),
    draftUpdatedByAdminId: text("draft_updated_by_admin_id")
      .references(() => lioraAdminUsersTable.id, { onDelete: "set null" }),
    publishedByAdminId: text("published_by_admin_id")
      .references(() => lioraAdminUsersTable.id, { onDelete: "set null" }),
    updatedByAdminId: text("updated_by_admin_id")
      .references(() => lioraAdminUsersTable.id, { onDelete: "set null" }),
    draftUpdatedAt: timestamp("draft_updated_at", { withTimezone: true }),
    publishedAt: timestamp("published_at", { withTimezone: true }),
    updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [
    check("liora_seo_settings_singleton_check", sql`${table.id} = 'default'`),
    check("liora_seo_settings_revision_check", sql`${table.revision} >= 0`),
  ],
);

export const lioraSeoSettingsHistoryTable = pgTable(
  "liora_seo_settings_history",
  {
    id: text("id").primaryKey(),
    revision: integer("revision").notNull(),
    action: varchar("action", { length: 24 }).$type<LioraSeoHistoryAction>().notNull(),
    settings: jsonb("settings").$type<LioraSeoSettingsDocument>().notNull(),
    adminId: text("admin_id").references(() => lioraAdminUsersTable.id, { onDelete: "set null" }),
    reason: varchar("reason", { length: 500 }).notNull(),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [
    check("liora_seo_history_revision_check", sql`${table.revision} > 0`),
    check("liora_seo_history_action_check", sql`${table.action} in ('draft_saved', 'published', 'draft_discarded', 'restored_as_draft')`),
    uniqueIndex("liora_seo_history_revision_unique").on(table.revision),
    index("liora_seo_history_admin_created_idx").on(table.adminId, table.createdAt),
    index("liora_seo_history_created_idx").on(table.createdAt),
  ],
);

export type LioraSeoSettingsHistory = typeof lioraSeoSettingsHistoryTable.$inferSelect;
