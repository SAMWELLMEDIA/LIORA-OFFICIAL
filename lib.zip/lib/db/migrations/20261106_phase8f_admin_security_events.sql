CREATE TABLE IF NOT EXISTS "liora_admin_security_events" (
  "id" text PRIMARY KEY NOT NULL,
  "admin_id" text REFERENCES "liora_admin_users"("id") ON DELETE SET NULL,
  "event_type" varchar(48) NOT NULL,
  "outcome" varchar(16) NOT NULL,
  "http_method" varchar(12),
  "route" varchar(180),
  "source_fingerprint" varchar(64),
  "details" jsonb DEFAULT '{}'::jsonb NOT NULL,
  "created_at" timestamptz DEFAULT now() NOT NULL,
  CONSTRAINT "liora_admin_security_event_type_check"
    CHECK ("event_type" IN ('admin.login.success', 'admin.login.failure', 'admin.login.rate_limited', 'admin.logout.success', 'admin.api.unauthorized')),
  CONSTRAINT "liora_admin_security_outcome_check"
    CHECK ("outcome" IN ('success', 'failure', 'blocked'))
);

CREATE INDEX IF NOT EXISTS "liora_admin_security_created_idx"
  ON "liora_admin_security_events" ("created_at");
CREATE INDEX IF NOT EXISTS "liora_admin_security_admin_created_idx"
  ON "liora_admin_security_events" ("admin_id", "created_at");
CREATE INDEX IF NOT EXISTS "liora_admin_security_source_created_idx"
  ON "liora_admin_security_events" ("source_fingerprint", "created_at");
CREATE INDEX IF NOT EXISTS "liora_admin_member_activity_created_idx"
  ON "liora_admin_member_activity" ("created_at");
CREATE INDEX IF NOT EXISTS "liora_admin_payment_activity_created_idx"
  ON "liora_admin_payment_activity" ("created_at");
CREATE INDEX IF NOT EXISTS "liora_platform_settings_audit_created_idx"
  ON "liora_platform_settings_audit" ("created_at");
CREATE INDEX IF NOT EXISTS "liora_homepage_content_audit_created_idx"
  ON "liora_homepage_content_audit" ("created_at");
CREATE INDEX IF NOT EXISTS "liora_website_content_audit_created_idx"
  ON "liora_website_content_audit" ("created_at");
CREATE INDEX IF NOT EXISTS "liora_country_configuration_audit_created_idx"
  ON "liora_country_configuration_audit" ("created_at");
CREATE INDEX IF NOT EXISTS "liora_email_admin_audit_created_idx"
  ON "liora_email_admin_audit" ("created_at");
