-- Phase 8B only. Review and back up the target database before applying.
-- This file has NOT been applied to production.
-- Unlike a full schema push, this script does not alter existing tables,
-- constraints, member records, payment records, or homepage content.
BEGIN;
SET LOCAL lock_timeout = '5s';

CREATE TABLE IF NOT EXISTS liora_website_content_versions (
  id text PRIMARY KEY,
  content_type varchar(24) NOT NULL,
  version integer NOT NULL,
  status varchar(16) NOT NULL,
  content jsonb NOT NULL,
  created_by_admin_id text REFERENCES liora_admin_users(id) ON DELETE SET NULL,
  updated_by_admin_id text REFERENCES liora_admin_users(id) ON DELETE SET NULL,
  published_by_admin_id text REFERENCES liora_admin_users(id) ON DELETE SET NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  published_at timestamptz,
  CONSTRAINT liora_website_content_type_check CHECK (content_type IN ('about', 'testimonials', 'faq')),
  CONSTRAINT liora_website_content_status_check CHECK (status IN ('draft', 'published', 'archived', 'discarded')),
  CONSTRAINT liora_website_content_version_check CHECK (version > 0)
);

CREATE UNIQUE INDEX IF NOT EXISTS liora_website_content_type_version_unique
  ON liora_website_content_versions (content_type, version);
CREATE UNIQUE INDEX IF NOT EXISTS liora_website_content_one_draft_idx
  ON liora_website_content_versions (content_type) WHERE status = 'draft';
CREATE UNIQUE INDEX IF NOT EXISTS liora_website_content_one_published_idx
  ON liora_website_content_versions (content_type) WHERE status = 'published';
CREATE INDEX IF NOT EXISTS liora_website_content_type_status_updated_idx
  ON liora_website_content_versions (content_type, status, updated_at);

CREATE TABLE IF NOT EXISTS liora_website_content_audit (
  id text PRIMARY KEY,
  content_type varchar(24) NOT NULL,
  admin_id text REFERENCES liora_admin_users(id) ON DELETE SET NULL,
  action varchar(32) NOT NULL,
  version_id text REFERENCES liora_website_content_versions(id) ON DELETE SET NULL,
  version integer NOT NULL,
  details jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT liora_website_content_audit_type_check CHECK (content_type IN ('about', 'testimonials', 'faq'))
);
CREATE INDEX IF NOT EXISTS liora_website_content_audit_admin_created_idx
  ON liora_website_content_audit (admin_id, created_at);
CREATE INDEX IF NOT EXISTS liora_website_content_audit_type_created_idx
  ON liora_website_content_audit (content_type, created_at);
CREATE INDEX IF NOT EXISTS liora_website_content_audit_version_created_idx
  ON liora_website_content_audit (version_id, created_at);

COMMIT;
