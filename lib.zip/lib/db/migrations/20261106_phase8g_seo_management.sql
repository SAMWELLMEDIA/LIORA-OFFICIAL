CREATE TABLE IF NOT EXISTS liora_seo_settings (
  id varchar(24) PRIMARY KEY,
  draft jsonb,
  published jsonb,
  revision integer NOT NULL DEFAULT 0,
  draft_updated_by_admin_id text REFERENCES liora_admin_users(id) ON DELETE SET NULL,
  published_by_admin_id text REFERENCES liora_admin_users(id) ON DELETE SET NULL,
  updated_by_admin_id text REFERENCES liora_admin_users(id) ON DELETE SET NULL,
  draft_updated_at timestamptz,
  published_at timestamptz,
  updated_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT liora_seo_settings_singleton_check CHECK (id = 'default'),
  CONSTRAINT liora_seo_settings_revision_check CHECK (revision >= 0)
);

CREATE TABLE IF NOT EXISTS liora_seo_settings_history (
  id text PRIMARY KEY,
  revision integer NOT NULL,
  action varchar(24) NOT NULL,
  settings jsonb NOT NULL,
  admin_id text REFERENCES liora_admin_users(id) ON DELETE SET NULL,
  reason varchar(500) NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT liora_seo_history_revision_check CHECK (revision > 0),
  CONSTRAINT liora_seo_history_action_check CHECK (
    action IN ('draft_saved', 'published', 'draft_discarded', 'restored_as_draft')
  )
);

CREATE UNIQUE INDEX IF NOT EXISTS liora_seo_history_revision_unique
  ON liora_seo_settings_history (revision);
CREATE INDEX IF NOT EXISTS liora_seo_history_admin_created_idx
  ON liora_seo_settings_history (admin_id, created_at);
CREATE INDEX IF NOT EXISTS liora_seo_history_created_idx
  ON liora_seo_settings_history (created_at);
