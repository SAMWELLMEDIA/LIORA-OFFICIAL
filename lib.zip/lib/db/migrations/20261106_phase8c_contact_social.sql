-- Phase 8C: allow Contact Us and social/support-link versions in the existing
-- website content tables. This changes only the accepted metadata values;
-- existing website content, member, registration and payment rows are untouched.
BEGIN;

ALTER TABLE liora_website_content_versions
  DROP CONSTRAINT IF EXISTS liora_website_content_type_check,
  ADD CONSTRAINT liora_website_content_type_check
    CHECK (content_type IN ('about', 'testimonials', 'faq', 'contact', 'social-links'));

ALTER TABLE liora_website_content_audit
  DROP CONSTRAINT IF EXISTS liora_website_content_audit_type_check,
  ADD CONSTRAINT liora_website_content_audit_type_check
    CHECK (content_type IN ('about', 'testimonials', 'faq', 'contact', 'social-links'));

COMMIT;
