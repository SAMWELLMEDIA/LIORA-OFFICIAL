-- Phase 8D: store privacy-minimized page-view and registration-funnel events.
-- Visitor IDs are already one-way hashes; raw IP addresses and user agents are not stored.
-- Historical page views are not backfilled because they were never collected.
BEGIN;

CREATE TABLE IF NOT EXISTS liora_website_analytics_events (
  id text PRIMARY KEY,
  visitor_hash text NOT NULL,
  event_type varchar(32) NOT NULL,
  path varchar(200) NOT NULL,
  device_type varchar(16) NOT NULL DEFAULT 'unknown',
  occurred_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT liora_website_analytics_event_type_check
    CHECK (event_type IN ('page_view', 'register_click', 'registration_begin')),
  CONSTRAINT liora_website_analytics_device_type_check
    CHECK (device_type IN ('mobile', 'desktop', 'tablet', 'other', 'unknown')),
  CONSTRAINT liora_website_analytics_path_check
    CHECK (path LIKE '/%' AND path NOT LIKE '/api/%' AND path NOT LIKE '/admin/%' AND length(path) <= 200)
);

CREATE INDEX IF NOT EXISTS liora_website_analytics_event_time_idx
  ON liora_website_analytics_events (event_type, occurred_at);
CREATE INDEX IF NOT EXISTS liora_website_analytics_path_time_idx
  ON liora_website_analytics_events (path, occurred_at);
CREATE INDEX IF NOT EXISTS liora_website_analytics_visitor_time_idx
  ON liora_website_analytics_events (visitor_hash, occurred_at);
CREATE INDEX IF NOT EXISTS liora_website_analytics_device_time_idx
  ON liora_website_analytics_events (device_type, occurred_at);

COMMIT;
