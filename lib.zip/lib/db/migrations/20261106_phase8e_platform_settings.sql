-- Phase 8E: additive platform settings, announcements and attributed audit history.
-- Development-only until the owner separately approves production migration/deployment.
-- Does not alter member, registration, payment, withdrawal or balance records.
BEGIN;
SET LOCAL lock_timeout = '5s';

CREATE TABLE IF NOT EXISTS liora_platform_settings (
  id varchar(24) PRIMARY KEY CHECK (id = 'default'),
  settings jsonb NOT NULL,
  updated_by_admin_id text REFERENCES liora_admin_users(id) ON DELETE SET NULL,
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS liora_platform_announcements (
  id text PRIMARY KEY,
  title varchar(120) NOT NULL,
  message text NOT NULL,
  style varchar(16) NOT NULL CHECK (style IN ('notice', 'update', 'important')),
  starts_at timestamptz,
  ends_at timestamptz,
  status varchar(16) NOT NULL DEFAULT 'draft' CHECK (status IN ('draft', 'published', 'unpublished')),
  created_by_admin_id text REFERENCES liora_admin_users(id) ON DELETE SET NULL,
  updated_by_admin_id text REFERENCES liora_admin_users(id) ON DELETE SET NULL,
  published_by_admin_id text REFERENCES liora_admin_users(id) ON DELETE SET NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  published_at timestamptz,
  CONSTRAINT liora_platform_announcement_window_check
    CHECK (ends_at IS NULL OR starts_at IS NULL OR ends_at > starts_at)
);
CREATE INDEX IF NOT EXISTS liora_platform_announcement_active_idx
  ON liora_platform_announcements (status, starts_at, ends_at);
CREATE INDEX IF NOT EXISTS liora_platform_announcement_updated_idx
  ON liora_platform_announcements (updated_at);

CREATE TABLE IF NOT EXISTS liora_platform_settings_audit (
  id text PRIMARY KEY,
  admin_id text REFERENCES liora_admin_users(id) ON DELETE SET NULL,
  setting_key varchar(64) NOT NULL,
  previous_value jsonb,
  new_value jsonb,
  reason varchar(500) NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS liora_platform_settings_audit_admin_created_idx
  ON liora_platform_settings_audit (admin_id, created_at);
CREATE INDEX IF NOT EXISTS liora_platform_settings_audit_key_created_idx
  ON liora_platform_settings_audit (setting_key, created_at);

COMMIT;
