import assert from 'node:assert/strict';
import { randomBytes, scryptSync } from 'node:crypto';
import { readFile, writeFile, unlink } from 'node:fs/promises';

const statePath = new URL('./disposable-member-state.json', import.meta.url);
const reportPath = new URL('./status-backfill-verification.json', import.meta.url);
const mode = process.argv[2];
if (mode === 'prepare') {
  const token = randomBytes(6).toString('hex');
  const password = `Test!Aa7${randomBytes(24).toString('hex')}`;
  const salt = randomBytes(16);
  const hash = scryptSync(password, salt, 64, { N: 32768, r: 8, p: 1, maxmem: 64 * 1024 * 1024 });
  await writeFile(statePath, JSON.stringify({
    id: randomBytes(16).toString('hex'),
    username: `verify_${token}`,
    email: `liora-verification-${token}@example.invalid`,
    password,
    passwordHash: `scrypt$32768$8$1$${salt.toString('base64url')}$${hash.toString('base64url')}`,
    paymentId: randomBytes(16).toString('hex'),
    transactionReference: `development-verification-${token}`,
  }), { mode: 0o600, flag: 'wx' });
  console.log(JSON.stringify({ prepared: true }));
  process.exit(0);
}
if (mode === 'cleanup-state') {
  await unlink(statePath).catch(error => { if (error.code !== 'ENOENT') throw error; });
  console.log(JSON.stringify({ temporaryCredentialsRemoved: true }));
  process.exit(0);
}

const state = JSON.parse(await readFile(statePath, 'utf8'));
const origin = `https://${process.env.REPLIT_DEV_DOMAIN}`;
assert.ok(process.env.REPLIT_DEV_DOMAIN, 'Development host is required');
const report = mode === 'paid'
  ? JSON.parse(await readFile(reportPath, 'utf8'))
  : { environment: 'development', checks: {} };
let adminCookie;
let newMemberCookie;
function cookie(response, name) {
  return response.headers.getSetCookie().map(value => value.split(';')[0]).find(value => value.startsWith(`${name}=`));
}
async function request(path, { method = 'GET', data, session, requestOrigin = origin } = {}) {
  const response = await fetch(`${origin}/api${path}`, {
    method,
    headers: {
      Origin: requestOrigin,
      ...(data ? { 'Content-Type': 'application/json' } : {}),
      ...(session ? { Cookie: session } : {}),
    },
    ...(data ? { body: JSON.stringify(data) } : {}),
    redirect: 'error',
  });
  const body = response.headers.get('content-type')?.includes('application/json')
    ? await response.json() : await response.text();
  return { response, status: response.status, body };
}
async function profile() {
  const result = await request(`/admin/users/${state.id}`, { session: adminCookie });
  assert.equal(result.status, 200, 'Profile request must succeed');
  return result.body;
}
async function backfill(options = {}) {
  return request('/admin/users/backfill-liora-keys', {
    method: 'POST', data: { confirm: true }, session: adminCookie, ...options,
  });
}
async function memberLogin() {
  return request('/auth/login', {
    method: 'POST',
    data: { identifier: state.username, password: state.password, remember: false },
  });
}
try {
  const login = await request('/admin/auth/login', {
    method: 'POST',
    data: { identifier: 'SAMWELL_MEDIA', password: process.env.LIORA_ADMIN_INITIAL_PASSWORD, remember: false },
  });
  assert.equal(login.status, 200, 'Development admin sign-in must succeed');
  adminCookie = cookie(login.response, 'liora_admin_session');
  assert.ok(adminCookie, 'Admin session must be issued');
  const adminName = login.body.admin?.displayName ?? login.body.displayName ?? 'LIORA_ADMIN';

  if (mode === 'pending') {
    const before = await profile();
    assert.equal(before.user.paymentStatus, 'pending');
    assert.equal(before.user.lioraKey, null);
    await request(`/admin/users?q=${state.username}`, { session: adminCookie });
    await request(`/admin/users/export?format=csv&q=${state.username}`, { session: adminCookie });
    assert.equal((await profile()).user.lioraKey, null);
    assert.equal((await backfill({ session: undefined })).status, 401);
    assert.equal((await backfill({ requestOrigin: 'https://untrusted.example.invalid' })).status, 403);
    assert.equal((await backfill({ data: { confirm: false } })).status, 400);
    const result = await backfill();
    assert.equal(result.status, 200);
    assert.equal(result.body.assignedCount, 0);
    const after = await profile();
    assert.equal(after.user.lioraKey, null);
    assert.equal(after.user.accountStatus, before.user.accountStatus);
    assert.equal(after.user.paymentStatus, before.user.paymentStatus);
    report.checks.pendingRemainsKeyless = true;
    report.checks.explicitAdminOriginAndConfirmationRequired = true;
  } else if (mode === 'paid') {
    const before = await profile();
    assert.equal(before.user.paymentStatus, 'successful');
    assert.equal(before.user.lioraKey, null, 'Profile GET must not generate a key');
    await request(`/admin/users?q=${state.username}`, { session: adminCookie });
    await request(`/admin/users/export?format=excel&q=${state.username}`, { session: adminCookie });
    assert.equal((await profile()).user.lioraKey, null, 'Directory and export GET must not generate a key');
    report.checks.readRequestsDoNotGenerateKeys = true;
    const concurrent = await Promise.all([backfill(), backfill()]);
    concurrent.forEach(result => assert.equal(result.status, 200));
    assert.deepEqual(concurrent.map(result => result.body.assignedCount).sort(), [0, 1]);
    const keyed = await profile();
    const originalKey = keyed.user.lioraKey;
    assert.match(originalKey, /^LIO-[0-9A-F]{32}$/);
    assert.equal(keyed.user.accountStatus, before.user.accountStatus);
    assert.equal(keyed.user.paymentStatus, before.user.paymentStatus);
    const repeated = await backfill();
    assert.equal(repeated.status, 200);
    assert.equal(repeated.body.assignedCount, 0);
    assert.equal((await profile()).user.lioraKey, originalKey);
    report.checks.concurrentBackfillAssignedExactlyOnce = true;
    report.checks.repeatedBackfillPreservesExistingKeyAndStatuses = true;

    const firstLogin = await memberLogin();
    const secondLogin = await memberLogin();
    assert.equal(firstLogin.status, 200);
    assert.equal(secondLogin.status, 200);
    const oldCookies = [firstLogin, secondLogin].map(result => cookie(result.response, 'liora_session'));
    assert.ok(oldCookies.every(Boolean));
    for (const session of oldCookies) assert.equal((await request('/auth/me', { session })).status, 200);
    const expected = [];
    async function change(status, reason, previousStatus) {
      const result = await request(`/admin/users/${state.id}/status`, {
        method: 'PATCH', session: adminCookie, data: { status, reason },
      });
      assert.equal(result.status, 200);
      assert.equal(result.body.changed, true);
      expected.push({ previousStatus, newStatus: status, reason });
      const current = await profile();
      assert.equal(current.user.accountStatus, status);
      assert.equal(current.user.paymentStatus, 'successful');
      assert.equal(current.user.lioraKey, originalKey);
      const events = current.accountActivity.filter(event => event.kind === 'status_changed');
      assert.equal(events.length, expected.length);
      assert.equal(new Set(events.map(event => event.id)).size, expected.length);
      for (const entry of expected) {
        const matches = events.filter(event =>
          event.previousStatus === entry.previousStatus &&
          event.newStatus === entry.newStatus && event.reason === entry.reason &&
          event.actorName === adminName && Number.isFinite(Date.parse(event.createdAt)));
        assert.equal(matches.length, 1, 'Each action must have exactly one correct audit event');
      }
      const retry = await request(`/admin/users/${state.id}/status`, {
        method: 'PATCH', session: adminCookie, data: { status, reason },
      });
      assert.equal(retry.status, 200);
      assert.equal(retry.body.changed, false);
      assert.equal((await profile()).accountActivity.filter(event => event.kind === 'status_changed').length, expected.length);
    }
    await change('active', 'Disposable verification: eligible paid activation', 'pending_payment');
    report.checks.eligiblePaidMemberActivated = true;
    await change('suspended', 'Disposable verification: suspension and session revocation', 'active');
    for (const session of oldCookies) assert.equal((await request('/auth/me', { session })).status, 401);
    report.checks.allExistingMemberSessionsRevoked = true;
    assert.equal((await memberLogin()).status, 403);
    report.checks.suspendedMemberCannotSignIn = true;
    await change('active', 'Disposable verification: reactivation', 'suspended');
    const reLogin = await memberLogin();
    assert.equal(reLogin.status, 200);
    newMemberCookie = cookie(reLogin.response, 'liora_session');
    assert.ok(newMemberCookie);
    assert.equal((await request('/auth/me', { session: newMemberCookie })).status, 200);
    for (const session of oldCookies) assert.equal((await request('/auth/me', { session })).status, 401);
    report.checks.reactivatedMemberCanSignInWithNewSession = true;
    report.checks.oldSessionsRemainInvalidAfterReactivation = true;
    report.checks.originalKeyAndPaidStatusPreservedThroughout = true;
    report.checks.exactlyThreeCorrectAuditRecords = true;
    report.checks.idempotentStatusRetriesCreateNoExtraAuditRecords = true;
  } else {
    throw new Error('Unknown verification mode');
  }
  await writeFile(reportPath, JSON.stringify(report, null, 2));
  console.log(JSON.stringify(report));
} finally {
  if (newMemberCookie) await request('/auth/logout', { method: 'POST', session: newMemberCookie }).catch(() => {});
  if (adminCookie) await request('/admin/auth/logout', { method: 'POST', session: adminCookie }).catch(() => {});
}
