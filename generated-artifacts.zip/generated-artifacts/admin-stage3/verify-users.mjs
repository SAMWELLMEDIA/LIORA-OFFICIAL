import { spawn } from 'node:child_process';
import { mkdir, rm, writeFile } from 'node:fs/promises';

const origin = `https://${process.env.REPLIT_DEV_DOMAIN}`;
const password = process.env.LIORA_ADMIN_INITIAL_PASSWORD;
const out = 'generated-artifacts/admin-stage3';
if (!process.env.REPLIT_DEV_DOMAIN || !password) {
  throw new Error('Required development preview or admin-login configuration is unavailable.');
}

await mkdir(out, { recursive: true });
const chromeEnv = { ...process.env };
delete chromeEnv.LIORA_ADMIN_INITIAL_PASSWORD;
delete chromeEnv.LIORA_ADMIN_BOOTSTRAP_TOKEN;
const profile = `/tmp/liora-stage3-browser-${Date.now()}`;
const chrome = spawn('/repl/tools/bin/chromium', [
  '--headless',
  '--no-sandbox',
  '--disable-dev-shm-usage',
  '--no-proxy-server',
  '--remote-debugging-port=9240',
  `--user-data-dir=${profile}`,
  'about:blank',
], { stdio: 'ignore', env: chromeEnv });

const delay = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
const pending = new Map();
const results = { screenshots: [], overflow: [], checks: {} };
let ws;
let sequence = 0;

try {
  let ready = false;
  for (let attempt = 0; attempt < 100; attempt += 1) {
    try {
      await fetch('http://127.0.0.1:9240/json/version');
      ready = true;
      break;
    } catch {
      await delay(100);
    }
  }
  if (!ready) throw new Error('Local Chromium did not start.');

  const page = await (await fetch('http://127.0.0.1:9240/json/new?about:blank', { method: 'PUT' })).json();
  ws = new WebSocket(page.webSocketDebuggerUrl);
  await new Promise((resolve, reject) => {
    ws.addEventListener('open', resolve, { once: true });
    ws.addEventListener('error', () => reject(new Error('Browser protocol connection failed.')), { once: true });
  });
  ws.addEventListener('message', (event) => {
    const message = JSON.parse(event.data);
    if (message.id && pending.has(message.id)) {
      const action = pending.get(message.id);
      pending.delete(message.id);
      if (message.error) action.reject(new Error('Browser protocol command failed.'));
      else action.resolve(message.result);
    }
  });

  const send = (method, params = {}) => new Promise((resolve, reject) => {
    const id = ++sequence;
    pending.set(id, { resolve, reject });
    ws.send(JSON.stringify({ id, method, params }));
  });
  const evaluate = async (expression) => {
    const result = await send('Runtime.evaluate', {
      expression,
      returnByValue: true,
      awaitPromise: true,
    });
    if (result.exceptionDetails) throw new Error('Browser evaluation failed.');
    return result.result?.value;
  };
  const until = async (expression, label) => {
    for (let attempt = 0; attempt < 150; attempt += 1) {
      if (await evaluate(expression)) return;
      await delay(100);
    }
    throw new Error(`Timed out while checking ${label}.`);
  };
  const viewport = async (width, height, mobile) => {
    await send('Emulation.setDeviceMetricsOverride', {
      width,
      height,
      deviceScaleFactor: 1,
      mobile,
    });
    await delay(350);
  };
  const click = async (expression) => {
    const point = await evaluate(`(() => {
      const element = ${expression};
      if (!element) throw new Error('Control unavailable.');
      const rect = element.getBoundingClientRect();
      return { x: rect.x + rect.width / 2, y: rect.y + rect.height / 2 };
    })()`);
    await send('Input.dispatchMouseEvent', { type: 'mouseMoved', ...point });
    await send('Input.dispatchMouseEvent', { type: 'mousePressed', ...point, button: 'left', clickCount: 1 });
    await send('Input.dispatchMouseEvent', { type: 'mouseReleased', ...point, button: 'left', clickCount: 1 });
  };
  const screenshot = async (name) => {
    const capture = await send('Page.captureScreenshot', { format: 'png', captureBeyondViewport: false });
    const path = `${out}/${name}.png`;
    await writeFile(path, Buffer.from(capture.data, 'base64'));
    results.screenshots.push(path);
  };
  const checkWidth = async (label) => {
    const width = await evaluate('({ viewport: innerWidth, document: document.documentElement.scrollWidth, body: document.body.scrollWidth })');
    const noOverflow = width.document <= width.viewport && width.body <= width.viewport;
    results.overflow.push({ label, ...width, noOverflow });
    if (!noOverflow) throw new Error(`Horizontal overflow found at ${label}.`);
  };

  await send('Page.enable');
  await send('Runtime.enable');
  await send('Network.enable');
  await viewport(1440, 960, false);
  await send('Page.navigate', { url: `${origin}/admin/login` });
  await until("Boolean(document.querySelector('#admin-identifier'))", 'admin login page');
  await until("Object.keys(document.querySelector('form') || {}).some(key => key.startsWith('__reactProps'))", 'admin login hydration');
  await evaluate("document.querySelector('#admin-identifier').focus()");
  await send('Input.insertText', { text: 'SAMWELL_MEDIA' });
  await evaluate("document.querySelector('#admin-password').focus()");
  await send('Input.insertText', { text: password });
  await click("Array.from(document.querySelectorAll('button')).find(button => button.textContent.trim() === 'Sign in')");
  await until("location.pathname === '/admin/dashboard' && document.body.textContent.includes('Operational overview')", 'authenticated admin dashboard');
  results.checks.adminLogin = true;

  await click("Array.from(document.querySelectorAll('button')).find(button => button.textContent.includes('Users'))");
  await until("document.body.textContent.includes('Member directory')", 'member directory');
  await until("Boolean(document.querySelector('[data-testid^=\"row-user-\"]'))", 'real member records');
  results.checks.directoryRendered = true;
  await checkWidth('desktop-1440');
  await screenshot('users-desktop');

  const api = await evaluate(`(async () => {
    const response = await fetch('/api/admin/users?page=1&pageSize=100', { cache: 'no-store' });
    const payload = await response.json();
    const user = payload.users?.[0];
    return {
      status: response.status,
      count: payload.users?.length ?? 0,
      summary: payload.summary,
      pageSize: payload.pagination?.pageSize,
      hasRequestedFields: Boolean(user && ['fullName','username','email','phoneNumber','country','createdAt','paymentStatus','accountStatus','lioraKey'].every(key => Object.hasOwn(user, key))),
      firstId: user?.id ?? null,
      searchTerm: user?.username ?? '',
      country: user?.country ?? '',
      firstPayment: user?.paymentStatus ?? '',
      firstKey: user?.lioraKey ?? null
    };
  })()`);
  if (api.status !== 200 || api.count < 1 || !api.summary || !api.hasRequestedFields) {
    throw new Error('Member list response or account-wide summary did not match the contract.');
  }
  const memberId = api.firstId;
  const summary = api.summary;
  results.checks.pendingKeyPolicy =
    api.firstPayment === 'successful' || api.firstKey === null;
  delete api.firstId;
  delete api.searchTerm;
  delete api.country;
  delete api.firstPayment;
  delete api.firstKey;
  results.checks.directoryApi = api;
  if (!results.checks.pendingKeyPolicy) throw new Error('An unverified member was issued a LIORA key.');
  const searchCheck = await evaluate(`(async () => {
    const term = ${JSON.stringify((await evaluate(`(async()=>{const r=await fetch('/api/admin/users?pageSize=1');const d=await r.json();return d.users?.[0]?.username??''})()`)) || '')};
    const response = await fetch('/api/admin/users?q=' + encodeURIComponent(term.toUpperCase()) + '&page=1&pageSize=10');
    const payload = await response.json();
    return { status: response.status, found: payload.users?.some(user => user.username.toLowerCase() === term.toLowerCase()) ?? false };
  })()`);
  if (searchCheck.status !== 200 || !searchCheck.found) throw new Error('Case-insensitive member search failed.');
  results.checks.caseInsensitiveSearch = true;

  const profileCheck = await evaluate(`(async () => {
    const response = await fetch('/api/admin/users/${memberId}', { cache: 'no-store' });
    const payload = await response.json();
    const profile = payload.user;
    return {
      status: response.status,
      profile: Boolean(profile && profile.id === ${JSON.stringify(memberId)}),
      hasPaymentHistory: Array.isArray(payload.paymentHistory),
      hasRegistrationActivity: payload.accountActivity?.some(item => item.kind === 'registration') ?? false,
      noCredentialFields: Boolean(profile && !('passwordHash' in profile) && !('sessionToken' in profile))
    };
  })()`);
  if (profileCheck.status !== 200 || !profileCheck.profile || !profileCheck.hasPaymentHistory || !profileCheck.hasRegistrationActivity || !profileCheck.noCredentialFields) {
    throw new Error('Member profile, account history or field-safety check failed.');
  }
  results.checks.profile = profileCheck;

  const filterAndExport = await evaluate(`(async () => {
    const initial = await fetch('/api/admin/users?page=1&pageSize=1').then(response => response.json());
    const first = initial.users?.[0];
    const country = first?.country ?? '';
    const accountStatus = first?.accountStatus ?? 'all';
    const countryResponse = await fetch('/api/admin/users?country=' + encodeURIComponent(country));
    const accountResponse = await fetch('/api/admin/users?accountStatus=' + encodeURIComponent(accountStatus));
    const sortedResponse = await fetch('/api/admin/users?sortBy=name&sortOrder=asc');
    const pending = await fetch('/api/admin/users?paymentStatus=pending&page=1&pageSize=10');
    const pendingBody = await pending.json();
    const paid = await fetch('/api/admin/users/export?format=csv&paymentStatus=paid');
    const csv = await fetch('/api/admin/users/export?format=csv&paymentStatus=pending');
    const csvText = await csv.text();
    const excel = await fetch('/api/admin/users/export?format=excel&paymentStatus=pending');
    const excelText = await excel.text();
    return {
      pendingStatus: pending.status,
      countryFilterStatus: countryResponse.status,
      accountFilterStatus: accountResponse.status,
      sortedStatus: sortedResponse.status,
      paidExportStatus: paid.status,
      csvStatus: csv.status,
      csvHeaders: csvText.includes('Full name') && csvText.includes('LIORA key'),
      csvDownloadName: csv.headers.get('content-disposition')?.includes('liora-members.csv') ?? false,
      excelStatus: excel.status,
      excelWorkbook: excelText.includes('<Workbook') && excelText.includes('LIORA key'),
      excelDownloadName: excel.headers.get('content-disposition')?.includes('liora-members.xls') ?? false,
      pendingCount: pendingBody.pagination?.total ?? 0
    };
  })()`);
  if (filterAndExport.pendingStatus !== 200 || filterAndExport.countryFilterStatus !== 200 ||
      filterAndExport.accountFilterStatus !== 200 || filterAndExport.sortedStatus !== 200 ||
      filterAndExport.paidExportStatus !== 200 || filterAndExport.csvStatus !== 200 || !filterAndExport.csvHeaders ||
      !filterAndExport.csvDownloadName || filterAndExport.excelStatus !== 200 || !filterAndExport.excelWorkbook ||
      !filterAndExport.excelDownloadName) {
    throw new Error('Filtering or CSV/Excel export verification failed.');
  }
  results.checks.filtersAndExports = filterAndExport;

  const paymentState = await evaluate(`(async () => {
    const profile = await fetch('/api/admin/users/${memberId}').then(response => response.json());
    return profile.user?.paymentStatus ?? '';
  })()`);
  if (paymentState !== 'successful') {
    const activationAttempt = await evaluate(`(async () => {
      const response = await fetch('/api/admin/users/${memberId}/status', {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status: 'active', reason: 'Verification of unpaid activation guard' })
      });
      return response.status;
    })()`);
    if (activationAttempt !== 409) throw new Error('Unpaid accounts were not blocked from activation.');
    results.checks.unpaidActivationBlocked = true;
    const profileAfter = await evaluate(`fetch('/api/admin/users/${memberId}').then(response => response.json()).then(payload => ({ status: payload.user.accountStatus, activity: payload.accountActivity.length }))`);
    results.checks.rejectedActivationNoChange = profileAfter.status === 'pending_payment' && profileAfter.activity === 1;
    if (!results.checks.rejectedActivationNoChange) throw new Error('Rejected activation changed member state or audit history.');
  } else {
    results.checks.unpaidActivationBlocked = 'skipped; first record is already paid';
  }

  await click("document.querySelector('[data-testid^=\"open-user-\"]')");
  await until("Boolean(document.querySelector('[data-testid=\"user-profile\"]'))", 'member detail view');
  await until("Boolean(document.querySelector('[data-testid=\"activate-user\"]') || document.querySelector('[data-testid=\"suspend-user\"]'))", 'member status action');
  if (paymentState !== 'successful') {
    results.checks.activationDisabledForUnpaid =
      await evaluate("document.querySelector('[data-testid=\"activate-user\"]')?.disabled === true");
    if (!results.checks.activationDisabledForUnpaid) {
      throw new Error('The activation control was not disabled for an unpaid member.');
    }
  }
  await evaluate("document.querySelector('[data-testid=\"user-profile\"]').scrollIntoView({block:'start'})");
  await delay(400);
  await screenshot('user-profile-desktop');

  await viewport(390, 844, true);
  await evaluate('window.scrollTo(0, 0)');
  await checkWidth('mobile-390');
  await screenshot('users-mobile');
  await click("document.querySelector('button[aria-label=\"Open admin navigation\"]')");
  await until("Boolean(document.querySelector('[role=\"dialog\"]'))", 'mobile navigation drawer');
  await checkWidth('mobile-390-drawer');
  results.checks.mobileNavigationDrawer = true;
  await send('Input.dispatchKeyEvent', { type: 'keyDown', key: 'Escape', code: 'Escape' });
  await send('Input.dispatchKeyEvent', { type: 'keyUp', key: 'Escape', code: 'Escape' });
  await until("!document.querySelector('[role=\"dialog\"]')", 'mobile navigation drawer close');
  await evaluate("document.querySelector('[data-testid=\"user-profile\"]')?.scrollIntoView({block:'start'})");
  await delay(350);
  await checkWidth('mobile-profile-390');
  await screenshot('user-profile-mobile');
  await viewport(320, 740, true);
  await evaluate('window.scrollTo(0, 0)');
  await checkWidth('mobile-320');
  results.checks.accountSummary = summary;

  await click("document.querySelector('button[aria-label^=\"Open profile menu\"]')");
  await until("Boolean(document.querySelector('[role=\"menu\"]'))", 'admin profile menu');
  results.checks.profileMenu = true;
  await click("Array.from(document.querySelectorAll('[role=\"menuitem\"]')).find(item => item.textContent.includes('Log out'))");
  await until("location.pathname === '/admin/login'", 'logout redirect');
  results.checks.adminSessionAfterLogout = await evaluate("fetch('/api/admin/users', { credentials: 'same-origin', cache: 'no-store' }).then(response => response.status)");
  await evaluate("document.cookie = 'liora_session=member-session-check; Path=/; SameSite=Lax'");
  results.checks.memberCookieUsersStatus = await evaluate("fetch('/api/admin/users', { credentials: 'same-origin', cache: 'no-store' }).then(response => response.status)");
  if (results.checks.adminSessionAfterLogout !== 401 || results.checks.memberCookieUsersStatus !== 401) {
    throw new Error('An inactive administrator or member-style session accessed the users API.');
  }

  await writeFile(`${out}/verification.json`, JSON.stringify(results, null, 2));
  console.log(JSON.stringify(results, null, 2));
} catch (error) {
  console.log(`verification_error=${error instanceof Error ? error.message : 'unknown'}`);
  process.exitCode = 1;
} finally {
  if (ws) ws.close();
  chrome.kill('SIGTERM');
  await delay(250);
  await rm(profile, { recursive: true, force: true }).catch(() => {});
}
