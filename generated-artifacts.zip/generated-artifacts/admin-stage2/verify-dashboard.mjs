import { spawn } from 'node:child_process';
import { mkdir, writeFile, rm } from 'node:fs/promises';

const origin = `https://${process.env.REPLIT_DEV_DOMAIN}`;
const password = process.env.LIORA_ADMIN_INITIAL_PASSWORD;
const out = 'generated-artifacts/admin-stage2';
if (!process.env.REPLIT_DEV_DOMAIN || !password) {
  throw new Error('Required development preview or admin-login configuration is unavailable.');
}

await mkdir(out, { recursive: true });
const chromeEnv = { ...process.env };
delete chromeEnv.LIORA_ADMIN_INITIAL_PASSWORD;
delete chromeEnv.LIORA_ADMIN_BOOTSTRAP_TOKEN;
const profile = `/tmp/liora-stage2-browser-${Date.now()}`;
const chrome = spawn('/repl/tools/bin/chromium', [
  '--headless',
  '--no-sandbox',
  '--disable-dev-shm-usage',
  '--no-proxy-server',
  '--remote-debugging-port=9238',
  `--user-data-dir=${profile}`,
  'about:blank',
], { stdio: 'ignore', env: chromeEnv });

const delay = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
const pending = new Map();
const results = { screenshots: [], overflow: [], requestStatuses: {} };
let ws;
let sequence = 0;

try {
  let ready = false;
  for (let attempt = 0; attempt < 100; attempt += 1) {
    try {
      await fetch('http://127.0.0.1:9238/json/version');
      ready = true;
      break;
    } catch {
      await delay(100);
    }
  }
  if (!ready) throw new Error('Local Chromium did not start.');

  const page = await (await fetch('http://127.0.0.1:9238/json/new?about:blank', { method: 'PUT' })).json();
  ws = new WebSocket(page.webSocketDebuggerUrl);
  await new Promise((resolve, reject) => {
    ws.addEventListener('open', resolve, { once: true });
    ws.addEventListener('error', () => reject(new Error('Browser protocol connection failed.')), { once: true });
  });

  ws.addEventListener('message', (event) => {
    const message = JSON.parse(event.data);
    if (message.method === 'Network.responseReceived') {
      const { url } = message.params.response;
      if (url.includes('/api/analytics/page-view')) results.requestStatuses.visitor = message.params.response.status;
      if (url.includes('/api/admin/dashboard/overview')) results.requestStatuses.dashboard = message.params.response.status;
    }
    if (message.id && pending.has(message.id)) {
      const action = pending.get(message.id);
      pending.delete(message.id);
      if (message.error) action.reject(new Error('Browser protocol command failed.'));
      else action.resolve(message.result);
    }
  });

  const send = (method, params = {}) => new Promise((resolve, reject) => {
    const id = ++sequence;
    pending.set(id, { resolve, reject });
    ws.send(JSON.stringify({ id, method, params }));
  });
  const evaluate = async (expression) => {
    const result = await send('Runtime.evaluate', {
      expression,
      returnByValue: true,
      awaitPromise: true,
    });
    if (result.exceptionDetails) throw new Error('Browser evaluation failed.');
    return result.result?.value;
  };
  const until = async (expression, label) => {
    for (let attempt = 0; attempt < 150; attempt += 1) {
      if (await evaluate(expression)) return;
      await delay(100);
    }
    throw new Error(`Timed out while checking ${label}.`);
  };
  const viewport = async (width, height, mobile) => {
    await send('Emulation.setDeviceMetricsOverride', {
      width,
      height,
      deviceScaleFactor: 1,
      mobile,
    });
    await delay(350);
  };
  const screenshot = async (name) => {
    const capture = await send('Page.captureScreenshot', {
      format: 'png',
      captureBeyondViewport: false,
    });
    const path = `${out}/${name}.png`;
    await writeFile(path, Buffer.from(capture.data, 'base64'));
    results.screenshots.push(path);
  };
  const click = async (expression) => {
    const point = await evaluate(`(() => {
      const element = ${expression};
      if (!element) throw new Error('Control unavailable.');
      const rect = element.getBoundingClientRect();
      return { x: rect.x + rect.width / 2, y: rect.y + rect.height / 2 };
    })()`);
    await send('Input.dispatchMouseEvent', { type: 'mouseMoved', ...point });
    await send('Input.dispatchMouseEvent', { type: 'mousePressed', ...point, button: 'left', clickCount: 1 });
    await send('Input.dispatchMouseEvent', { type: 'mouseReleased', ...point, button: 'left', clickCount: 1 });
  };
  const checkWidth = async (label) => {
    const width = await evaluate('({ viewport: innerWidth, document: document.documentElement.scrollWidth, body: document.body.scrollWidth })');
    const noOverflow = width.document <= width.viewport && width.body <= width.viewport;
    results.overflow.push({ label, ...width, noOverflow });
    if (!noOverflow) throw new Error(`Horizontal overflow found at ${label}.`);
  };
  const fetchOverview = (query) => evaluate(`fetch('/api/admin/dashboard/overview?${query}', { credentials: 'same-origin', cache: 'no-store' }).then(async response => {
    const body = await response.json();
    return { status: response.status, body };
  })`);

  await send('Page.enable');
  await send('Runtime.enable');
  await send('Network.enable');

  await viewport(1440, 1000, false);
  await send('Page.navigate', { url: `${origin}/` });
  await until("document.readyState === 'complete'", 'homepage load');
  await delay(1200);
  results.visitorTracking = results.requestStatuses.visitor ?? null;

  await send('Page.navigate', { url: `${origin}/admin/login` });
  await until("Boolean(document.querySelector('#admin-identifier'))", 'admin login page');
  await until("Object.keys(document.querySelector('form') || {}).some(key => key.startsWith('__reactProps'))", 'admin login hydration');
  await evaluate("document.querySelector('#admin-identifier').focus()");
  await send('Input.insertText', { text: 'SAMWELL_MEDIA' });
  await evaluate("document.querySelector('#admin-password').focus()");
  await send('Input.insertText', { text: password });
  await click("Array.from(document.querySelectorAll('button')).find(button => button.textContent.trim() === 'Sign in')");
  await until("location.pathname === '/admin/dashboard' && document.body.textContent.includes('Total Registered Users')", 'authenticated dashboard and data');
  await until("document.body.textContent.includes('Last updated')", 'loaded overview data');
  results.adminLogin = true;

  const allTime = await fetchOverview('range=allTime&granularity=day');
  results.dashboardStatus = allTime.status;
  results.timeZone = allTime.body.timeZone;
  results.summary = allTime.body.metrics;
  results.today = allTime.body.today;
  results.paymentDistribution = allTime.body.paymentDistribution;
  if (allTime.status !== 200 || allTime.body.timeZone !== 'Africa/Lagos') {
    throw new Error('Authenticated dashboard API or reporting timezone check failed.');
  }

  const today = await fetchOverview('range=today&granularity=day');
  results.todayRange = { status: today.status, from: today.body.range?.from, to: today.body.range?.to };
  if (today.status !== 200 || !today.body.range?.from || today.body.range.from !== today.body.range.to) {
    throw new Error('Today date-range calculation failed.');
  }
  const custom = await fetchOverview(`range=custom&from=${today.body.range.from}&to=${today.body.range.to}&granularity=day`);
  results.customRangeStatus = custom.status;
  const invalidCustom = await fetchOverview(`range=custom&from=${today.body.range.from}&to=2000-01-01&granularity=day`);
  results.invalidCustomRangeStatus = invalidCustom.status;
  const monthly = await fetchOverview('range=last30Days&granularity=month');
  results.monthlyGranularityStatus = monthly.status;
  if (custom.status !== 200 || invalidCustom.status !== 400 || monthly.status !== 200) {
    throw new Error('Custom date or chart-granularity check failed.');
  }

  await checkWidth('desktop-1440');
  await screenshot('overview-desktop');
  await evaluate("document.querySelector('[aria-labelledby=\"trends-heading\"]')?.scrollIntoView({ block: 'start' })");
  await delay(350);
  await screenshot('overview-desktop-trends');

  await viewport(390, 1000, true);
  await evaluate('window.scrollTo(0, 0)');
  await checkWidth('mobile-390');
  await screenshot('overview-mobile');
  await click("document.querySelector('button[aria-label=\"Open admin navigation\"]')");
  await until("Boolean(document.querySelector('[role=\"dialog\"]'))", 'mobile navigation drawer');
  await checkWidth('mobile-390-drawer');
  await screenshot('overview-mobile-drawer');
  await send('Input.dispatchKeyEvent', { type: 'keyDown', key: 'Escape', code: 'Escape' });
  await send('Input.dispatchKeyEvent', { type: 'keyUp', key: 'Escape', code: 'Escape' });
  await until("!document.querySelector('[role=\"dialog\"]')", 'drawer close');

  await viewport(320, 740, true);
  await checkWidth('mobile-320');

  await click("document.querySelector('button[aria-label^=\"Open profile menu\"]')");
  await until("Boolean(document.querySelector('[role=\"menu\"]'))", 'admin profile menu');
  results.profileMenu = true;
  await click("Array.from(document.querySelectorAll('[role=\"menuitem\"]')).find(item => item.textContent.includes('Log out'))");
  await until("location.pathname === '/admin/login'", 'logout redirect');
  results.logoutRedirect = true;
  results.adminSessionAfterLogout = await evaluate("fetch('/api/admin/auth/session', { credentials: 'same-origin', cache: 'no-store' }).then(response => response.status)");
  results.dashboardAfterLogout = await evaluate("fetch('/api/admin/dashboard/overview?range=allTime&granularity=day', { credentials: 'same-origin', cache: 'no-store' }).then(response => response.status)");
  await evaluate("document.cookie = 'liora_session=member-session-check; Path=/; SameSite=Lax'");
  results.memberCookieDashboardStatus = await evaluate("fetch('/api/admin/dashboard/overview?range=allTime&granularity=day', { credentials: 'same-origin', cache: 'no-store' }).then(response => response.status)");
  if (results.adminSessionAfterLogout !== 401 || results.dashboardAfterLogout !== 401 || results.memberCookieDashboardStatus !== 401) {
    throw new Error('An inactive administrator or member-style session accessed a protected API.');
  }

  await send('Page.navigate', { url: `${origin}/admin/dashboard` });
  await until("location.pathname === '/admin/login' && Boolean(document.querySelector('#admin-identifier'))", 'protected dashboard after logout');
  results.dashboardPageAfterLogout = 'redirected-to-login';
  await writeFile(`${out}/verification.json`, JSON.stringify(results, null, 2));
  console.log(JSON.stringify(results, null, 2));
} catch (error) {
  console.log(`verification_error=${error instanceof Error ? error.message : 'unknown'}`);
  process.exitCode = 1;
} finally {
  if (ws) ws.close();
  chrome.kill('SIGTERM');
  await delay(250);
  await rm(profile, { recursive: true, force: true }).catch(() => {});
}
