# LIORA Stage 2 — Dashboard Overview & Daily Analytics

## Delivered

The existing `/admin/dashboard` Overview is connected to PostgreSQL. Other administration sections remain placeholders. Existing authentication, provisioning, registration and payment workflows are unchanged.

- Six summary cards with Font Awesome icons and descriptions.
- Independent daily performance section.
- Today, Yesterday, Last 7 Days, Last 30 Days, This Month, All Time and inclusive custom-date filters.
- Daily, weekly and monthly registration and confirmed-revenue charts, plus paid/pending distribution.
- Separate currency totals and series; currencies are never added together.
- Recent registrations, confirmed payments and pending registrations with name, username, country, timestamp and status.
- Clean empty states. Administrator activity explicitly says unavailable because no audit event source currently exists.
- Loading/error states, manual refresh, optional automatic refresh (off by default; minimum five minutes), CSV chart exports, print and theme controls.
- Responsive layout retaining the existing sidebar, drawer, topbar and profile menu.

## Database sources

| Metric | Table and fields | Calculation |
|---|---|---|
| Registered users | `liora_accounts.id`, `created_at` | Count accounts created in the selected period; All Time has no date restriction. |
| Paid users | `liora_accounts.payment_status`, `activated_at` | Count successful registrations activated in the selected period. |
| Pending users | `liora_accounts.status`, `payment_status`, `created_at` | Count `pending_payment` accounts with pending payment, registered in the selected period. |
| Website visitors | `liora_visitor_daily.visitor_hash`, `visit_date` | Count distinct pseudonymous browser identifiers during the selected period. |
| Registration revenue | `liora_payment_attempts.status`, `verified_at`, `amount`, `currency` | Sum successful, verified payments by currency and actual verification timestamp. |
| Today's revenue | Same payment fields | Sum successful, verified payments within today's Lagos boundaries, independent of the global filter. |

Daily registrations use account creation timestamps. Daily confirmed payments use payment verification timestamps, not account creation. Someone registering earlier and paying today contributes to today's payment count and revenue, not today's new registrations. Daily pending registrations use today's account-creation cohort and its current pending status.

All reporting uses `Africa/Lagos`. Timestamp comparisons use an inclusive start and exclusive next-day end. Custom date endpoints are inclusive. Chart buckets use Lagos local dates. Weekly buckets follow PostgreSQL's Monday-based week.

Activity additionally reads account `full_name`, `username`, `country`, `status` and `payment_status`, and payment `account_id`, `created_at` and `verified_at`. No passwords, payment credentials or contact details are displayed.

## Visitor collection and limits

No existing reliable visitor source was available. A minimal public-layout tracker now submits a first-party visit signal. A random HTTP-only cookie identifies a browser; only its hash and Lagos date/first-seen/last-seen timestamps are stored. No IP address, user agent, page path or contact details are collected.

The browser prevents duplicate in-flight/day requests, and the database primary key deduplicates browser/day records. Cookie deletion, different devices or different browsers can count separately; this is not a verified count of individual people.

There is no historical visitor data from before tracking. Development totals include verification browser visits and are not production traffic. The public privacy notice should be reviewed before enabling this tracker in production; that notice was not rewritten in this Stage 2 task.

## Additive development schema changes

Applied in development using:

```sh
pnpm --filter @workspace/db run push
```

- New `liora_visitor_daily` table with primary key `(visitor_hash, visit_date)`.
- New `liora_visitor_daily_date_idx` on `visit_date`.
- New `liora_accounts_created_at_idx` on `created_at`.
- New `liora_accounts_activated_at_idx` on `activated_at`.
- New `liora_payment_attempts_status_verified_at_idx` on `(status, verified_at)`.

Existing member, registration, payment and administrator rows were not replaced or seeded. No production migration was run. Production rollout requires a separate approved database review and additive migration against the production connection; do not use `push-force`.

## Verification results

- LIORA optimized production build: passed.
- API production build and API typecheck: passed.
- LIORA typecheck and shared-library typecheck: passed.
- API tests: 3 passed.
- Website suite: 29 passed, 2 existing unrelated failures, 15 production-only tests skipped.
  - Old route-list expectation does not include the already-existing admin routes.
  - Privacy-date expectation requires environment-driven dates despite the previously approved fixed policy dates.
- Signed-in browser check: login and protected overview API passed.
- Actual development totals at final verification: 1 registered, 0 paid, 1 pending, no confirmed registration revenue. Visitor count included development validation visits.
- Lagos Today/custom boundaries, invalid custom range rejection and monthly granularity: passed.
- Desktop 1440px, mobile 390px and 320px, and mobile drawer: no horizontal overflow.
- Profile menu and logout redirect: passed.
- After logout, admin session and overview APIs returned 401; the dashboard redirected to login.
- A member-style cookie without a valid dedicated administrator session was rejected with 401. Authorization also requires an active admin/super-admin record.
- Signed-in screenshots: desktop overview, desktop charts, mobile overview and mobile drawer.

## Files created or modified

Application and API:

- `artifacts/api-server/src/routes/admin-dashboard.ts`
- `artifacts/api-server/src/routes/index.ts`
- `artifacts/api-server/src/routes/visitor-analytics.ts`
- `artifacts/liora/src/app/(public)/layout.tsx` — invisible minimal visitor tracker only; no public content/layout redesign.
- `artifacts/liora/src/components/admin/AdminDashboardShell.tsx`
- `artifacts/liora/src/components/admin/AdminOverview.tsx`
- `artifacts/liora/src/components/admin/AdminVisitorTracker.ts`

Contract, code generation and schema:

- `lib/api-spec/openapi.yaml`
- `lib/api-spec/orval.config.ts`
- `lib/api-client-react/src/generated/api.schemas.ts`
- `lib/api-client-react/src/generated/api.ts`
- `lib/api-zod/src/generated/api.ts`
- `lib/api-zod/src/generated/types/adminActionActivity.ts`
- `lib/api-zod/src/generated/types/adminDashboardOverview.ts`
- `lib/api-zod/src/generated/types/adminDashboardOverviewMetrics.ts`
- `lib/api-zod/src/generated/types/adminDashboardOverviewPaymentDistribution.ts`
- `lib/api-zod/src/generated/types/adminDashboardOverviewRange.ts`
- `lib/api-zod/src/generated/types/adminDashboardOverviewRecentActivity.ts`
- `lib/api-zod/src/generated/types/adminDashboardOverviewTimeZone.ts`
- `lib/api-zod/src/generated/types/adminDashboardOverviewToday.ts`
- `lib/api-zod/src/generated/types/adminPaymentActivity.ts`
- `lib/api-zod/src/generated/types/adminRegistrationActivity.ts`
- `lib/api-zod/src/generated/types/currencyAmount.ts`
- `lib/api-zod/src/generated/types/getAdminDashboardOverviewGranularity.ts`
- `lib/api-zod/src/generated/types/getAdminDashboardOverviewParams.ts`
- `lib/api-zod/src/generated/types/getAdminDashboardOverviewRange.ts`
- `lib/api-zod/src/generated/types/index.ts`
- `lib/api-zod/src/generated/types/registrationTrendPoint.ts`
- `lib/api-zod/src/generated/types/revenueTrendPoint.ts`
- `lib/api-zod/src/generated/types/visitorPageViewRecorded.ts`
- `lib/api-zod/src/generated/types/visitorPageViewRecordedStatus.ts`
- `lib/db/src/schema/index.ts`
- `lib/db/src/schema/liora-accounts.ts`
- `lib/db/src/schema/liora-visitor-analytics.ts`

Verification outputs are under `generated-artifacts/admin-stage2/`: `verify-dashboard.mjs`, `verification.json`, four screenshots and this report. A durable PostgreSQL grouping lesson was recorded in `.agents/memory/postgres-chart-grouping.md` and indexed in `.agents/memory/MEMORY.md`.

## Scope confirmation

No Users management, Payment management, Countries & Pricing, campaigns, notifications, content management or full visitor analytics were built. No public page content, member workflow, authentication or provisioning behavior was changed. No Stage 3 work was started.
