import { spawn } from 'node:child_process';
import { mkdir, writeFile, rm } from 'node:fs/promises';

const origin = `https://${process.env.REPLIT_DEV_DOMAIN}`;
const password = process.env.LIORA_ADMIN_INITIAL_PASSWORD;
const out = 'generated-artifacts/admin-stage1';
await mkdir(out, { recursive: true });
const chromeEnv = { ...process.env };
delete chromeEnv.LIORA_ADMIN_INITIAL_PASSWORD;
delete chromeEnv.LIORA_ADMIN_BOOTSTRAP_TOKEN;
const profile = `/tmp/liora-admin-browser-${Date.now()}`;
const chrome = spawn('/repl/tools/bin/chromium', [
  '--headless', '--no-sandbox', '--disable-dev-shm-usage', '--no-proxy-server',
  '--remote-debugging-port=9237', `--user-data-dir=${profile}`, 'about:blank',
], { stdio: 'ignore', env: chromeEnv });
const delay = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
let ws;
const pending = new Map();
let seq = 0;
const results = { screenshots: [], sections: [], widths: [] };

try {
  let ready = false;
  for (let i = 0; i < 100; i++) {
    try { await fetch('http://127.0.0.1:9237/json/version'); ready = true; break; }
    catch { await delay(100); }
  }
  if (!ready) throw new Error('Local Chromium did not start');
  const page = await (await fetch('http://127.0.0.1:9237/json/new?about:blank', { method: 'PUT' })).json();
  ws = new WebSocket(page.webSocketDebuggerUrl);
  await new Promise((resolve, reject) => {
    ws.addEventListener('open', resolve, { once: true });
    ws.addEventListener('error', () => reject(new Error('CDP connection failed')), { once: true });
  });
  ws.addEventListener('message', (event) => {
    const msg = JSON.parse(event.data);
    if (msg.id && pending.has(msg.id)) {
      const p = pending.get(msg.id);
      pending.delete(msg.id);
      if (msg.error) p.reject(new Error('Browser protocol command failed'));
      else p.resolve(msg.result);
    }
  });
  const send = (method, params = {}) => new Promise((resolve, reject) => {
    const id = ++seq;
    pending.set(id, { resolve, reject });
    ws.send(JSON.stringify({ id, method, params }));
  });
  const evaluate = async (expression) => {
    const r = await send('Runtime.evaluate', { expression, returnByValue: true, awaitPromise: true });
    if (r.exceptionDetails) throw new Error('Browser evaluation failed');
    return r.result?.value;
  };
  const until = async (expression, label) => {
    for (let i = 0; i < 150; i++) {
      if (await evaluate(expression)) return;
      await delay(100);
    }
    throw new Error(`Timed out: ${label}`);
  };
  const screenshot = async (name) => {
    const r = await send('Page.captureScreenshot', { format: 'png', captureBeyondViewport: false });
    const path = `${out}/${name}.png`;
    await writeFile(path, Buffer.from(r.data, 'base64'));
    results.screenshots.push(path);
  };
  const viewport = async (width, height, mobile) => {
    await send('Emulation.setDeviceMetricsOverride', { width, height, deviceScaleFactor: 1, mobile });
    await delay(300);
  };
  const widthCheck = async (label) => {
    const v = await evaluate('({viewport:innerWidth,document:document.documentElement.scrollWidth,body:document.body.scrollWidth})');
    results.widths.push({ label, ...v, noOverflow: v.document <= v.viewport && v.body <= v.viewport });
    if (v.document > v.viewport || v.body > v.viewport) throw new Error(`Horizontal overflow: ${label}`);
  };
  const click = async (expression) => {
    const point = await evaluate(`(()=>{const el=${expression};if(!el)throw new Error('Control unavailable');const r=el.getBoundingClientRect();return {x:r.x+r.width/2,y:r.y+r.height/2};})()`);
    await send('Input.dispatchMouseEvent', { type: 'mouseMoved', ...point });
    await send('Input.dispatchMouseEvent', { type: 'mousePressed', ...point, button: 'left', clickCount: 1 });
    await send('Input.dispatchMouseEvent', { type: 'mouseReleased', ...point, button: 'left', clickCount: 1 });
  };
  const escape = async () => {
    await send('Input.dispatchKeyEvent', { type: 'keyDown', key: 'Escape', code: 'Escape' });
    await send('Input.dispatchKeyEvent', { type: 'keyUp', key: 'Escape', code: 'Escape' });
  };
  await send('Page.enable');
  await send('Runtime.enable');
  await send('Network.enable');
  await viewport(1440, 1000, false);
  await send('Page.navigate', { url: `${origin}/admin/login` });
  await until("Boolean(document.querySelector('#admin-identifier'))", 'login page');
  await until("Object.keys(document.querySelector('form')||{}).some(k=>k.startsWith('__reactProps'))", 'login hydration');
  await evaluate("document.querySelector('#admin-identifier').focus()");
  await send('Input.insertText', { text: 'SAMWELL_MEDIA' });
  await evaluate("document.querySelector('#admin-password').focus()");
  await send('Input.insertText', { text: password });
  await click("Array.from(document.querySelectorAll('button')).find(b=>b.textContent.trim()==='Sign in')");
  await until("location.pathname==='/admin/dashboard' && Boolean(document.querySelector('nav[aria-label=\"Admin sections\"]'))", 'successful UI sign-in');
  results.uiLogin = true;
  await delay(300);
  await widthCheck('desktop-1440');
  await screenshot('dashboard-desktop');
  const sections = ['Overview', 'Users', 'Payments', 'Visitors & Analytics', 'Countries & Pricing', 'Email Campaigns', 'Push Notifications', 'Website Content', 'Admin Activity', 'Settings'];
  for (const section of sections) {
    await click(`Array.from(document.querySelectorAll('nav[aria-label="Admin sections"] button')).find(b=>b.offsetParent!==null && b.textContent.startsWith(${JSON.stringify(section)}))`);
    await until(`document.querySelector('h1')?.textContent===${JSON.stringify(section)}`, `section ${section}`);
    if (!await evaluate(`document.body.textContent.includes(${JSON.stringify(`${section} is not yet available`)})`)) throw new Error(`Missing placeholder ${section}`);
    results.sections.push(section);
  }
  await click("Array.from(document.querySelectorAll('nav[aria-label=\"Admin sections\"] button')).find(b=>b.offsetParent!==null && b.textContent.startsWith('Overview'))");
  await click("document.querySelector('button[aria-label^=\"Open profile menu\"]')");
  await until("Boolean(document.querySelector('[role=menu]'))", 'profile menu');
  results.profileMenu = await evaluate("document.querySelector('[role=menu]').textContent.includes('LIORA_ADMIN') && document.querySelector('[role=menu]').textContent.includes('super_admin')");
  results.searchDisabled = await evaluate("document.querySelector('input[aria-label=\"Search, not yet available\"]')?.disabled===true");
  results.notificationsDisabled = await evaluate("document.querySelector('button[aria-label=\"Notifications, not yet available\"]')?.disabled===true");
  await screenshot('dashboard-profile-menu');
  await escape();
  await viewport(390, 844, true);
  await widthCheck('mobile-390');
  await screenshot('dashboard-mobile');
  await click("document.querySelector('button[aria-label=\"Open admin navigation\"]')");
  await until("Boolean(document.querySelector('[role=dialog]'))", 'mobile drawer');
  await delay(300);
  await widthCheck('mobile-390-drawer');
  await screenshot('dashboard-mobile-drawer');
  await click("Array.from(document.querySelectorAll('[role=dialog] nav button')).find(b=>b.textContent.startsWith('Users'))");
  await until("document.querySelector('h1')?.textContent==='Users' && !document.querySelector('[role=dialog]')", 'mobile selection closes drawer');
  results.mobileDrawerSelection = true;
  await viewport(320, 740, true);
  await widthCheck('mobile-320');
  await click("document.querySelector('button[aria-label=\"Open admin navigation\"]')");
  await until("Boolean(document.querySelector('[role=dialog]'))", '320 drawer');
  await delay(300);
  await widthCheck('mobile-320-drawer');
  await escape();
  await until("!document.querySelector('[role=dialog]')", 'drawer closes');
  await click("document.querySelector('button[aria-label^=\"Open profile menu\"]')");
  await until("Boolean(document.querySelector('[role=menu]'))", 'mobile profile');
  await click("Array.from(document.querySelectorAll('[role=menuitem]')).find(b=>b.textContent.includes('Log out'))");
  await until("location.pathname==='/admin/login'", 'logout redirect');
  results.uiLogout = true;
  results.postLogoutSessionStatus = await evaluate("fetch('/api/admin/auth/session').then(r=>r.status)");
  await send('Page.navigate', { url: `${origin}/admin/dashboard` });
  await until("location.pathname==='/admin/login' && Boolean(document.querySelector('#admin-identifier'))", 'protected dashboard after logout');
  results.postLogoutDashboardBlocked = true;
  await writeFile(`${out}/browser-verification.json`, JSON.stringify(results, null, 2));
  console.log(JSON.stringify(results, null, 2));
} catch (error) {
  console.log(`verification_error=${error.message}`);
  process.exitCode = 1;
} finally {
  if (ws) ws.close();
  chrome.kill('SIGTERM');
  await delay(250);
  await rm(profile, { recursive: true, force: true }).catch(() => {});
}
