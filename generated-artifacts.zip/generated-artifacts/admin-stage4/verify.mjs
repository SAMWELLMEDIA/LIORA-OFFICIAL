import assert from "node:assert/strict";
import { randomUUID, randomBytes, createHash } from "node:crypto";
import { createRequire } from "node:module";
import { readFile, writeFile, unlink } from "node:fs/promises";
import path from "node:path";
const root = process.cwd();
const require = createRequire(path.join(root, "artifacts/api-server/package.json"));
const { build } = require("esbuild");
const { Client } = createRequire(path.join(root, "lib/db/package.json"))("pg");
const output = path.join(root, "artifacts/api-server/node_modules/.cache/stage4-harness.mjs");
await build({
  entryPoints: [path.join(root, "generated-artifacts/admin-stage4/harness.ts")],
  outfile: output, bundle: true, platform: "node", format: "esm",
  external: ["pg-native", "express", "@google-cloud/*", "google-auth-library"],
  alias: {
    "@workspace/db": path.join(root, "lib/db/src/index.ts"),
    "@workspace/api-zod": path.join(root, "lib/api-zod/src/index.ts"),
  },
  banner: { js: "import { createRequire as __createRequire } from 'node:module'; const require = __createRequire(import.meta.url);" },
});
const h = await import(output);
const client = new Client({ connectionString: process.env.DATABASE_URL });
await client.connect();
const identity = (await client.query("select current_database() as name, (select oid from pg_database where datname=current_database()) as oid")).rows[0];
assert.deepEqual(identity, { name: "heliumdb", oid: 16384 }, "Only the explicitly confirmed development database may be tested");
const statePath = "/tmp/liora-stage4-fixtures.json";
const reportPath = path.join(root, "generated-artifacts/admin-stage4/verification.json");
const storage = new h.ObjectStorageService();
const mode = process.argv[2] ?? "test";
const origin = `https://${process.env.REPLIT_DEV_DOMAIN}`;
const png = Buffer.from("iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+/l9sAAAAASUVORK5CYII=", "base64");
const checks = {};
let state;
async function saveState() {
  await writeFile(statePath, JSON.stringify(state), { mode: 0o600 });
}
async function request(endpoint, { session, method = "GET", data, customOrigin = origin } = {}) {
  const response = await fetch(`${origin}/api${endpoint}`, {
    method, headers: {
      Origin: customOrigin, ...(session ? { Cookie: session } : {}),
      ...(data ? { "Content-Type": "application/json" } : {}),
    }, ...(data ? { body: JSON.stringify(data) } : {}), redirect: "error",
  });
  const body = response.headers.get("content-type")?.includes("application/json")
    ? await response.json() : Buffer.from(await response.arrayBuffer());
  return { status: response.status, body, response };
}
async function account(label, country = "Ghana", currency = "GHS", amount = "100.00") {
  const id = randomUUID();
  const suffix = randomBytes(5).toString("hex");
  const token = randomBytes(32).toString("base64url");
  const username = `s4_${suffix}`;
  await client.query(`insert into liora_accounts
    (id,full_name,username,email,phone_number,country,password_hash,registration_amount,currency,welcome_bonus_amount,terms_accepted_at,privacy_accepted_at)
    values ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,now(),now())`,
    [id, `Stage 4 ${label}`, username, `${username}@example.invalid`, "+0000000000", country, state.passwordHash, amount, currency, "5.00"]);
  await client.query("insert into liora_sessions (token_hash,account_id,expires_at) values ($1,$2,now()+interval '2 hours')", [h.hashOpaqueToken(token), id]);
  state.accountIds.push(id);
  await saveState();
  return { id, username, session: `liora_session=${token}`, currency, amount };
}
async function upload(member, bytes = png, mime = "image/png") {
  const result = await request("/registration/manual-transfer/uploads", { session: member.session, method: "POST", data: { fileSize: bytes.length } });
  assert.equal(result.status, 201, JSON.stringify(result.body));
  h.CreateMemberReceiptUploadResponse.parse(result.body);
  const put = await fetch(result.body.uploadUrl, { method: "PUT", headers: { "Content-Type": mime }, body: bytes });
  assert.ok(put.ok, `Signed private upload must succeed (${put.status})`);
  return result.body;
}
async function submit(member, amount = member.amount, currency = member.currency, bytes = png, mime = "image/png") {
  const slot = await upload(member, bytes, mime);
  const result = await request("/registration/manual-transfer/receipts", { session: member.session, method: "POST", data: {
    uploadId: slot.uploadId, payerName: "Disposable test payer", description: "Development-only receipt verification",
    declaredAmount: amount, declaredCurrency: currency,
  } });
  assert.equal(result.status, 201, JSON.stringify(result.body));
  h.SubmitMemberPaymentReceiptResponse.parse(result.body);
  return { ...result.body, slot };
}
async function decision(paymentId, action, reason = "Development verification reason") {
  return request(`/admin/payments/${paymentId}/decision`, { session: state.adminSession, method: "POST", data: { action, reason, receiptReviewed: action === "approve" } });
}
async function accountState(id) {
  return (await client.query("select status,payment_status,liora_key from liora_accounts where id=$1", [id])).rows[0];
}
async function cleanup() {
  const paths = (await client.query(`select object_path from liora_receipt_upload_slots where account_id=any($1::text[])
    union select object_path from liora_payment_receipts where account_id=any($1::text[])`, [state.accountIds])).rows;
  for (const { object_path } of paths) {
    try { await (await storage.getObjectEntityFile(object_path)).delete(); } catch {}
  }
  await client.query("begin");
  try {
    await client.query("delete from liora_payment_receipts where account_id=any($1::text[])", [state.accountIds]);
    await client.query("delete from liora_accounts where id=any($1::text[])", [state.accountIds]);
    await client.query("delete from liora_admin_users where id=$1", [state.adminId]);
    if (state.configCreated) await client.query("delete from liora_manual_transfer_configs where country='Ghana' and bank_name='DEVELOPMENT TEST BANK'");
    await client.query("commit");
  } catch (error) { await client.query("rollback"); throw error; }
  const remaining = Number((await client.query("select count(*) from liora_accounts where id=any($1::text[])", [state.accountIds])).rows[0].count);
  assert.equal(remaining, 0);
  await unlink(statePath);
}
try {
  if (mode === "cleanup") {
    state = JSON.parse(await readFile(statePath, "utf8"));
    await cleanup();
    const report = JSON.parse(await readFile(reportPath, "utf8").catch(() => "{}"));
    report.disposableFixturesRemoved = true;
    await writeFile(reportPath, JSON.stringify(report, null, 2));
    console.log("Disposable Stage 4 accounts, sessions, audit/notification rows, receipts, objects and test bank configuration removed.");
  } else {
    const suffix = randomBytes(5).toString("hex");
    const password = `Test!Aa9${randomBytes(20).toString("hex")}`;
    state = {
      adminId: randomUUID(), adminUsername: `s4_admin_${suffix}`,
      adminEmail: `s4-admin-${suffix}@example.invalid`,
      password, passwordHash: await h.hashPassword(password), accountIds: [],
      configCreated: false,
    };
    await saveState();
    await client.query(`insert into liora_admin_users (id,email,username,display_name,password_hash,role,status)
      values ($1,$2,$3,'Stage 4 Verification Admin',$4,'super_admin','active')`,
      [state.adminId, state.adminEmail, state.adminUsername, state.passwordHash]);
    const login = await request("/admin/auth/login", { method: "POST", data: { identifier: state.adminUsername, password, remember: false } });
    assert.equal(login.status, 200, JSON.stringify(login.body));
    state.adminSession = login.response.headers.getSetCookie().map((v) => v.split(";")[0]).find((v) => v.startsWith("liora_admin_session="));
    assert.ok(state.adminSession);
    await saveState();
    const beforeConfig = await client.query("select country from liora_manual_transfer_configs where country='Ghana'");
    assert.equal(beforeConfig.rowCount, 0, "Test must not overwrite real country bank details");
    const member = await account("Manual Review Test");
    const other = await account("Other Member Test");
    assert.equal((await request("/registration/manual-transfer/config", { session: member.session })).body.available, false);
    checks.unconfiguredCountryCannotSubmit = (await request("/registration/manual-transfer/uploads", { session: member.session, method: "POST", data: { fileSize: png.length } })).status === 409;
    await client.query(`insert into liora_manual_transfer_configs (country,currency,bank_name,account_name,account_number,instructions,active)
      values ('Ghana','GHS','DEVELOPMENT TEST BANK','DISPOSABLE TEST ONLY','0000000000','Do not send money. Development-only fixture.',true)`);
    state.configCreated = true;
    await saveState();
    const config = await request("/registration/manual-transfer/config", { session: member.session });
    h.GetMemberManualTransferConfigResponse.parse(config.body);
    assert.equal(config.body.available, true);
    checks.configuredCountryAndStoredFee = config.body.expectedAmount === "100.00" && config.body.currency === "GHS";
    assert.equal((await request("/admin/payments", { session: member.session })).status, 401);
    assert.equal((await request("/admin/payments")).status, 401);
    assert.equal((await request("/registration/webhook/flutterwave", { method: "POST", data: { event: "charge.completed", data: { id: "invalid" } } })).status, 401);
    checks.memberAndAnonymousCannotAccessAdmin = true;
    assert.equal((await request("/registration/manual-transfer/uploads", { session: member.session, method: "POST", data: { fileSize: 8388609 } })).status, 400);
    const invalid = await upload(member, Buffer.from("<html>not a receipt</html>"), "image/png");
    assert.equal((await request("/registration/manual-transfer/receipts", { session: member.session, method: "POST", data: {
      uploadId: invalid.uploadId, payerName: "Test payer", description: "Invalid receipt", declaredAmount: "100.00", declaredCurrency: "GHS",
    } })).status, 400);
    checks.fileSizeAndMagicValidation = true;
    let receipt = await submit(member, "99.00");
    assert.equal((await decision(receipt.paymentId, "approve")).status, 400);
    assert.equal((await decision(receipt.paymentId, "reject", "")).status, 400);
    assert.equal((await decision(receipt.paymentId, "reject", "Wrong amount in disposable receipt")).status, 200);
    assert.equal((await accountState(member.id)).liora_key, null);
    receipt = await submit(member, "100.00", "USD");
    assert.equal((await decision(receipt.paymentId, "approve")).status, 400);
    assert.equal((await decision(receipt.paymentId, "reject", "Wrong currency in disposable receipt")).status, 200);
    checks.amountCurrencyMustMatchAndRejectionRemainsUnpaid = true;
    receipt = await submit(member);
    assert.equal((await request("/registration/manual-transfer/uploads", { session: member.session, method: "POST", data: { fileSize: png.length } })).status, 409);
    assert.equal((await request(`/admin/payments/${receipt.paymentId}/decision`, { session: state.adminSession, method: "POST", customOrigin: "https://untrusted.invalid", data: { action: "approve" } })).status, 403);
    const approvals = await Promise.all([decision(receipt.paymentId, "approve"), decision(receipt.paymentId, "approve")]);
    assert.deepEqual(approvals.map((v) => v.status).sort(), [200, 409]);
    const successful = approvals.find((v) => v.status === 200);
    h.DecideAdminPaymentResponse.parse(successful.body);
    const after = await accountState(member.id);
    assert.equal(after.status, "active"); assert.equal(after.payment_status, "successful"); assert.match(after.liora_key, /^LIO-/);
    assert.equal(successful.body.lioraKey, after.liora_key);
    assert.equal(Number((await client.query("select count(*) from liora_welcome_bonus_credits where account_id=$1", [member.id])).rows[0].count), 1);
    const actions = (await client.query("select action,count(*)::int as n from liora_admin_payment_activity where account_id=$1 group by action", [member.id])).rows;
    assert.equal(actions.find((v) => v.action === "receipt_submitted").n, 3);
    assert.equal(actions.find((v) => v.action === "payment_rejected").n, 2);
    assert.equal(actions.find((v) => v.action === "payment_approved").n, 1);
    checks.concurrentApprovalCreatesOneKeyBonusAndAudit = true;
    const detail = await request(`/admin/payments/${receipt.paymentId}`, { session: state.adminSession });
    h.GetAdminPaymentResponse.parse(detail.body);
    const finalReceipt = detail.body.receipts[0];
    assert.equal((await request(finalReceipt.fileEndpoint.replace("/api", ""), { session: other.session })).status, 401);
    assert.equal((await request(`/registration/manual-transfer/receipts/${receipt.receiptId}/file`, { session: other.session })).status, 404);
    assert.equal((await request(finalReceipt.fileEndpoint.replace("/api", ""))).status, 401);
    const adminFile = await request(finalReceipt.fileEndpoint.replace("/api", ""), { session: state.adminSession });
    assert.equal(adminFile.status, 200); assert.deepEqual(adminFile.body, png);
    assert.match(adminFile.response.headers.get("cache-control"), /no-store/);
    const memberFile = await request(`/registration/manual-transfer/receipts/${receipt.receiptId}/file`, { session: member.session });
    assert.equal(memberFile.status, 200); assert.deepEqual(memberFile.body, png);
    await fetch(receipt.slot.uploadUrl, { method: "PUT", body: Buffer.from("overwritten temporary upload") });
    assert.deepEqual((await request(finalReceipt.fileEndpoint.replace("/api", ""), { session: state.adminSession })).body, png);
    checks.receiptsPrivateOwnedAndImmutableAfterSubmission = true;
    for (const action of ["decline", "cancel"]) {
      const target = await account(`${action} Test`);
      const next = await submit(target);
      assert.equal((await decision(next.paymentId, action)).status, 200);
      assert.equal((await accountState(target.id)).liora_key, null);
      assert.equal(Number((await client.query("select count(*) from liora_welcome_bonus_credits where account_id=$1", [target.id])).rows[0].count), 0);
    }
    checks.declineCancelNeverActivateOrCredit = true;
    const overview = await request("/admin/payments/overview", { session: state.adminSession });
    h.GetAdminPaymentsOverviewResponse.parse(overview.body);
    assert.ok(overview.body.confirmedRevenue.some((v) => v.currency === "GHS" && Number(v.amount) >= 100));
    const list = await request("/admin/payments?paymentMethod=bank_transfer&currency=GHS&page=1&pageSize=2&fromDate=2020-01-01&toDate=2030-01-01", { session: state.adminSession });
    assert.equal(list.status, 200, JSON.stringify(list.body)); h.ListAdminPaymentsResponse.parse(list.body);
    assert.ok(list.body.payments.length <= 2);
    const history = await request("/member/payment-history", { session: member.session });
    h.GetMemberPaymentHistoryResponse.parse(history.body);
    assert.ok(history.body.payments.every((v) => v.accountId === member.id));
    const userProfile = await request(`/admin/users/${member.id}`, { session: state.adminSession });
    assert.equal(userProfile.status, 200, JSON.stringify(userProfile.body));
    assert.equal(userProfile.body.paymentHistory[0].paymentMethod, "bank_transfer");
    const notices = await request("/admin/payments/notifications", { session: state.adminSession });
    assert.equal(notices.status, 200); h.ListAdminPaymentNotificationsResponse.parse(notices.body);
    const ids = notices.body.notifications.map((v) => v.id);
    assert.equal((await request("/admin/payments/notifications/read", { session: state.adminSession, method: "POST", data: { notificationIds: ids } })).status, 200);
    checks.filtersDatesPaginationHistoryNotificationsAndUserProfile = true;
    const flw = await account("Mocked Flutterwave Test", "Nigeria", "NGN", "15000.00");
    const paymentId = randomUUID(), reference = `S4-MOCK-${randomUUID()}`, transactionId = `s4-${randomUUID()}`;
    await client.query(`insert into liora_payment_attempts (id,account_id,transaction_reference,amount,currency,payment_method) values ($1,$2,$3,15000,'NGN','flutterwave')`, [paymentId, flw.id, reference]);
    const realFetch = globalThis.fetch;
    let providerAmount = 14000, providerCurrency = "NGN", providerReference = reference, providerStatus = "successful", mockCalls = 0;
    globalThis.fetch = async (url, options) => {
      if (String(url).startsWith("https://api.flutterwave.com/")) {
        mockCalls++;
        return new Response(JSON.stringify({ status: "success", data: {
          id: transactionId, tx_ref: providerReference, status: providerStatus, amount: providerAmount, currency: providerCurrency,
        } }), { headers: { "Content-Type": "application/json" } });
      }
      return realFetch(url, options);
    };
    try {
      providerStatus = "pending";
      assert.equal((await h.verifyAndActivate(transactionId, reference)).status, "pending");
      assert.equal((await accountState(flw.id)).payment_status, "pending");
      assert.equal((await accountState(flw.id)).liora_key, null);
      checks.pendingFlutterwaveDoesNotActivate = true;
      providerStatus = "successful";
      await assert.rejects(h.verifyAndActivate(transactionId, reference));
      assert.equal((await accountState(flw.id)).liora_key, null);
      providerAmount = 15000; providerCurrency = "USD";
      await assert.rejects(h.verifyAndActivate(transactionId, reference));
      providerCurrency = "NGN"; providerReference = "not-the-recorded-reference";
      await assert.rejects(h.verifyAndActivate(transactionId, reference));
      providerReference = reference;
      await Promise.all([h.verifyAndActivate(transactionId, reference), h.verifyAndActivate(transactionId, reference)]);
      const paid = await accountState(flw.id);
      assert.equal(paid.status, "active"); assert.equal(paid.payment_status, "successful");
      await h.verifyAndActivate(transactionId, reference);
      assert.equal((await accountState(flw.id)).liora_key, paid.liora_key);
      assert.equal(Number((await client.query("select count(*) from liora_welcome_bonus_credits where account_id=$1", [flw.id])).rows[0].count), 1);
      assert.equal(Number((await client.query("select count(*) from liora_admin_payment_activity where payment_attempt_id=$1 and action='flutterwave_verified'", [paymentId])).rows[0].count), 1);
      checks.mockedFlutterwaveExactReferenceAmountCurrencyAndIdempotency = mockCalls === 7;
    } finally { globalThis.fetch = realFetch; }
    const uiMember = await account("UI Receipt Test");
    const uiReceipt = await submit(uiMember);
    state.uiMember = uiMember;
    state.uiPaymentId = uiReceipt.paymentId;
    await saveState();
    for (const [name, passed] of Object.entries(checks)) assert.equal(passed, true, name);
    await writeFile(reportPath, JSON.stringify({ environment: "development", liveProviderCalls: 0, checks, disposableFixturesRemoved: false }, null, 2));
    console.log(JSON.stringify({ passed: Object.keys(checks).length, liveProviderCalls: 0, browserFixtureReady: true }));
  }
} catch (error) {
  console.error(error instanceof Error ? error.stack : "Stage 4 verification failed");
  process.exitCode = 1;
} finally {
  await client.end();
  await h.pool.end();
}
